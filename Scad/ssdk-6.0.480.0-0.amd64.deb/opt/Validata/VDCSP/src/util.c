/*
 * Copyright (C) �� ����� 1997-1999
 * Copyright (C) �������� 1999-2018
 * ��� 䠩� ᮤ�ন� ���ଠ��,
 * ������� ᮡ�⢥������� �������� ��������.
 *
 * �� ���� �⮣� 䠩�� �� ����� ���� ᪮��஢���,
 * ��ࠢ����, ��ॢ����� �� ��㣨� �모,
 * ������������ ��� ������஢��� ��� ᯮᮡ��,
 * �⪮�����஢���, ��।��� �� �� � ��� ��
 * ���� ���������� ��⥬� ��� �।���⥫쭮��
 * �����祭�� ᮣ��襭�� � ��������� ��������.
 */

/******************************************************************************/

#include "util.h"

/******************************************************************************/

int
main(
    int argc,
    char ** argv)
{
    unsigned long rc = VCERT_E_GENERIC;
    int           idx, chr;

    char          tmpbuf[2048] = { 0 };
    char          * tmpstr     = NULL;
    char          * strloc     = NULL;

    static struct option long_options[] =
    {
        { "profile",   required_argument, NULL, 0x1001 },
        { "registry",  no_argument,       NULL, 0x1002 },
        { "minimal",   no_argument,       NULL, 0x1003 },
        { "alias",     required_argument, NULL, 0x1004 },
        { "auth",      required_argument, NULL, 0x1005 },

        { "hash",      no_argument,       NULL, 0x2001 },
        { "sign",      no_argument,       NULL, 0x2002 },
        { "verify",    no_argument,       NULL, 0x2003 },
        { "encrypt",   no_argument,       NULL, 0x2004 },
        { "decrypt",   no_argument,       NULL, 0x2005 },
        { "msginf",    no_argument,       NULL, 0x2006 },
        { "tssign",    no_argument,       NULL, 0x2007 },
        { "tsverif",   no_argument,       NULL, 0x2008 },
        { "ocspinf",   no_argument,       NULL, 0x2009 },
        { "tools",     no_argument,       NULL, 0x200A },

        { "ldap",      no_argument,       NULL, 0x3001 },
        { "aiacdp",    no_argument,       NULL, 0x3002 },
        { "sendcert",  no_argument,       NULL, 0x3003 },
        { "algorithm", required_argument, NULL, 0x3004 },
        { "delete",    required_argument, NULL, 0x3005 },
        { "format",    required_argument, NULL, 0x3006 },
        { "silent",    required_argument, NULL, 0x3007 },

        { "in",        required_argument, NULL, 0x4001 },
        { "out",       required_argument, NULL, 0x4002 },
        { "data",      required_argument, NULL, 0x4003 },

        { "recsubj",   required_argument, NULL, 0x5001 },
        { "rechash",   required_argument, NULL, 0x5002 },
        { "reckeyid",  required_argument, NULL, 0x5003 },
#ifdef _WIN32
        { "reclist",   required_argument, NULL, 0x5004 },
#endif

        { "policy",    required_argument, NULL, 0x6001 },
        { "eku",       required_argument, NULL, 0x6002 },
        { "info",      required_argument, NULL, 0x6003 },
        { "index",     required_argument, NULL, 0x6004 },
        { "url",       required_argument, NULL, 0x6005 },
        { "vertime",   required_argument, NULL, 0x6006 },

        { "stream",    no_argument,       NULL, 0x7001 },
        { "detached",  no_argument,       NULL, 0x7002 },
        { "revtime",   no_argument,       NULL, 0x7003 },
        { "partial",   no_argument,       NULL, 0x7004 },
        { "nolocal",   no_argument,       NULL, 0x7005 },
        { "nocache",   no_argument,       NULL, 0x7006 },
        { "attrib",    no_argument,       NULL, 0x7007 },
        { "1215mg",    no_argument,       NULL, 0x7008 },
        { "1215gh",    no_argument,       NULL, 0x7009 },
        { "1215mac",   no_argument,       NULL, 0x700A },
        { "keyagree",  no_argument,       NULL, 0x700B },

        { "crlupdate", optional_argument, NULL, 0x8001 },
        { "critical",  no_argument,       NULL, 0x8002 },

        { "help",      no_argument,       NULL,    '?' },

        {           0,                 0,    0,      0 }
    };

#ifdef _WIN32

#else  /* _WIN32 */

    do
    {
        sigset_t mask;
        int      intr;

#ifdef SIGRTMIN
        intr = SIGRTMIN + 5;
#else  /* SIGRTMIN */
        intr = SIGXCPU;
#endif /* SIGRTMIN */

        sigfillset(&mask),
            sigdelset(&mask, intr),
                sigdelset(&mask, SIGINT),
                    pthread_sigmask(SIG_BLOCK, &mask, NULL);
    }
    while (0);

#endif /* _WIN32 */

    flog = stdout;

    encrypt_p.flag |= FLAG_CMS_ENCRYPT_USEREMOTESEARCH;
    find_p.flag    |= FLAG_FIND_USEREMOTESEARCH;

    tssign_p.flag |= FLAG_TSP_REQUEST_INCLUDENONCE |
                     FLAG_TSP_REQUEST_ATTACHEDSIGNER;

    optarg = 0;
    optind = 0;
    opterr = 1;
    while ((chr = getopt_long_only(argc, argv, "", long_options, (int *) 0)) != EOF)
    {
        switch (chr)
        {
        case 0x1001:
            profile = (string_t) oem_to_char(optarg);
            break;

        case 0x1002:
            registry = 1;
            break;

        case 0x1003:
            minimal = 1;
            break;

        case 0x1004:
            certid.type     = ID_ALIAS;
            certid.id.alias = (string_t) oem_to_char(optarg);
            break;

        case 0x1005:
            passwd.len = strlen(optarg);
            passwd.buf = (string_t) optarg;
            break;


        case 0x2001:
            ophash = 1;
            break;

        case 0x2002:
            opsign = 1;
            break;

        case 0x2003:
            opvrfy = 1;
            break;

        case 0x2004:
            opencr = 1;
            break;

        case 0x2005:
            opdecr = 1;
            break;

        case 0x2006:
            msginf = 1;
            break;

        case 0x2007:
            optssg = 1;
            break;

        case 0x2008:
            optsvr = 1;
            break;

        case 0x2009:
            opocin = 1;
            break;

        case 0x200A:
            optool = 1;
            goto run;


        case 0x3001:
            ldap = 1;
            break;

        case 0x3002:
            aiacdp = 1;
            break;

        case 0x3003:
            sendcert = 1;
            break;

        case 0x3004:
            algorithm = (string_t) optarg;
            break;

        case 0x3005:
            verify_p.flag |= FLAG_CMS_VERIFY_DELETESIGNATURES;
            if (optarg)
                verify_p.nSignToDelete = atol(optarg);
            else
                verify_p.nSignToDelete = DELETE_ALL_SIGNS;
            break;

        case 0x3006:
            format = atol(optarg);
            break;

        case 0x3007:
            if (optarg)
                logfile = optarg;
            break;


        case 0x4001:
            finp = optarg;
            break;

        case 0x4002:
            fout = optarg;
            break;

        case 0x4003:
            fdat = optarg;
            break;


        case 0x5001:
            if (num_recipients >= MAX_NUM)
            {
#ifdef RUSSIAN
                file_print(flog, "������ ᫨誮� ����� �����⥫�� (���ᨬ� %d)\n", MAX_NUM);
#else
                file_print(flog, "too many recipients specified (maximum %d)\n", MAX_NUM);
#endif
                goto err;
            }
            recipients[num_recipients].subject = (string_t) (strloc = oem_to_char(optarg));
            if (strloc != optarg)
                recipients[num_recipients].fields |= FIELD_SUBJECT,
                    num_recipients ++;
            else
                recipients[num_recipients].subject = NULL;
            break;

        case 0x5002:
            if (num_recipients >= MAX_NUM)
            {
#ifdef RUSSIAN
                file_print(flog, "������ ᫨誮� ����� �����⥫�� (���ᨬ� %d)\n", MAX_NUM);
#else
                file_print(flog, "too many recipients specified (maximum %d)\n", MAX_NUM);
#endif
                goto err;
            }
            recipients[num_recipients].certHash.buf = string2hex(optarg, (int *) &recipients[num_recipients].certHash.len);
            if (recipients[num_recipients].certHash.buf)
                recipients[num_recipients].fields |= FIELD_CERTHASH,
                    num_recipients ++;
            break;

        case 0x5003:
            if (num_recipients >= MAX_NUM)
            {
#ifdef RUSSIAN
                file_print(flog, "������ ᫨誮� ����� �����⥫�� (���ᨬ� %d)\n", MAX_NUM);
#else
                file_print(flog, "too many recipients specified (maximum %d)\n", MAX_NUM);
#endif
                goto err;
            }
            recipients[num_recipients].keyId = (string_t) (strloc = oem_to_char(optarg));
            if (strloc != optarg)
                recipients[num_recipients].fields |= FIELD_KEYID,
                    num_recipients ++;
            else
                recipients[num_recipients].keyId = NULL;
            break;

#ifdef _WIN32
        case 0x5004:
            if (!load_recipients(optarg, recipients, &num_recipients))
                goto err;
            break;
#endif /* _WIN32 */


        case 0x6001:
            if (num_policies >= MAX_NUM)
            {
#ifdef RUSSIAN
                file_print(flog, "������ ᫨誮� ����� ����⨪ �ᯮ�짮����� ���䨪�� (���ᨬ� %d)\n", MAX_NUM);
#else
                file_print(flog, "too many policies specified (maximum %d)\n", MAX_NUM);
#endif
                goto err;
            }
            policies[num_policies ++] = optarg;
            break;

        case 0x6002:
            if (verify_p.extkeyusage_num >= MAX_NUM)
            {
#ifdef RUSSIAN
                file_print(flog, "������ ᫨誮� ����� ���७��� �����⥩ �ਬ������ ���� (���ᨬ� %d)\n", MAX_NUM);
#else
                file_print(flog, "too many extended key usages specified (maximum %d)\n", MAX_NUM);
#endif
                goto err;
            }
            extkeyus[num_extkeyus ++] = optarg;
            break;

        case 0x6003:
            if (strstr(optarg, "subject"))
                fields |= FIELD_SUBJECT;
            if (strstr(optarg, "issuer"))
                fields |= FIELD_ISSUER;
            if (strstr(optarg, "hash"))
                fields |= FIELD_CERTHASH;
            if (strstr(optarg, "keyid"))
                fields |= FIELD_KEYID;
            if (strstr(optarg, "altname"))
                fields |= FIELD_SUBJECTALTNAME;
            if (strstr(optarg, "serial"))
                fields |= FIELD_SERIAL;
            if (strstr(optarg, "notbefore"))
                fields |= FIELD_NOTBEFORE;
            if (strstr(optarg, "notafter"))
                fields |= FIELD_NOTAFTER;
            if (strstr(optarg, "algorithm"))
                fields |= FIELD_ALGORITHM;
            if (strstr(optarg, "all"))
                fields |= FIELD_ALL;
            break;

        case 0x6004:
            tssign_p.index = atol(optarg) - 1;
            tsverif_p.index = atol(optarg) - 1;
            break;

        case 0x6005:
            url = optarg;
            break;

        case 0x6006:
            policy_p.size = sizeof(policy_p);
            policy_p.check_time = atol(optarg);
            break;


        case 0x7001:
            stream = 1;
            break;

        case 0x7002:
            detached = 1;
            break;

        case 0x7003:
            verify_p.flag |= FLAG_CMS_VERIFY_USEREVOCATIONTIME;
            break;

        case 0x7004:
            encrypt_p.flag |= FLAG_CMS_ENCRYPT_SUBJECTISPARTIAL;
            find_p.flag    |= FLAG_FIND_SUBJECTISPARTIAL;
            break;

        case 0x7005:
            encrypt_p.flag |= FLAG_CMS_ENCRYPT_IGNORESTORELOCAL;
            find_p.flag    |= FLAG_FIND_IGNORESTORELOCAL;
            break;

        case 0x7006:
            encrypt_p.flag |= FLAG_CMS_ENCRYPT_IGNORESTORECACHE;
            find_p.flag    |= FLAG_FIND_IGNORESTORECACHE;
            break;

        case 0x7007:
            encrypt_p.flag |= FLAG_CMS_ENCRYPT_SUBJECTATTRIBUTE;
            find_p.flag    |= FLAG_FIND_SUBJECTATTRIBUTE;
            break;

        case 0x7008:
            encrypt_p.flag |= FLAG_CMS_ENCRYPT_GOST_R_34_12_15MG;
            break;

        case 0x7009:
            encrypt_p.flag |= FLAG_CMS_ENCRYPT_GOST_R_34_12_15GH;
            break;

        case 0x700A:
            encrypt_p.flag |= FLAG_CMS_ENCRYPT_ADDOMACATTRIBUTE;
            break;

        case 0x700B:
            encrypt_p.flag |= FLAG_CMS_ENCRYPT_RECIPKEYAGREEMENT;
            break;


        case 0x8001:
            crlupdate = 1;
            break;

        case 0x8002:
            critical = 1;
            break;


        default:
        case '?':
            print_help = 1;
            goto err;
        }
    }
    if (chr != EOF)
    {
        print_help = 1;
        goto err;
    }

 run:
#ifdef _LOCAL_
    if (0 == flag)
        flag |= FLAG_INIT_DISABLECRLUPDATE;
    if (0 == ldap)
        flag |= FLAG_INIT_DISABLELDAPUSAGE;
    if (0 != aiacdp)
        flag |= FLAG_INIT_ALLOWAIACDPUSAGE;
    if (0 != registry)
        flag |= FLAG_INIT_CERTSTOREPROFILE;
#endif /* _LOCAL_ */

    if (0 == fields)
        fields = FIELD_SUBJECT | FIELD_CERTHASH;

    if (policy_p.check_time > 0)
        fields |= FIELD_CERTENCODED;

    sign_p.mycert    = &certid;
    verify_p.mycert  = &certid;
    policy_p.mycert  = &certid;
    encrypt_p.mycert = &certid;
    decrypt_p.mycert = &certid;
    tssign_p.mycert  = &certid;
    tsverif_p.mycert = &certid;
    ocspsig_p.mycert = &certid;
    ocspver_p.mycert = &certid;
    find_p.mycert    = &certid;
    import_p.mycert  = &certid;
    export_p.mycert  = &certid;

    verify_p.info  = fields;
    decrypt_p.info = fields;
    tsverif_p.info = fields;
    ocspver_p.info = fields;
    find_p.info    = fields;

    if (num_extkeyus > 0)
    {
        verify_p.extkeyusage_num = num_extkeyus;
        verify_p.extKeyUsage     = malloc(sizeof(extension_t) * verify_p.extkeyusage_num);
        memset(verify_p.extKeyUsage, 0, sizeof(extension_t) * verify_p.extkeyusage_num);
        for (idx = 0; idx < num_extkeyus; idx ++)
            verify_p.extKeyUsage[idx].oid = (string_t) extkeyus[idx];
        verify_p.flag |= FLAG_CMS_VERIFY_SIGNEREXTKEYUSAGES;
    }
    if (num_policies > 0)
    {
        verify_p.policy_num = num_policies;
        verify_p.policies   = malloc(sizeof(policy_t) * verify_p.policy_num);
        memset(verify_p.policies, 0, sizeof(policy_t) * verify_p.policy_num);
        for (idx = 0; idx < num_policies; idx ++)
            verify_p.policies[idx].oid = (string_t) policies[idx];
        verify_p.flag |= FLAG_CMS_VERIFY_SIGNERPOLICIES;
    }
    if (num_recipients > 0)
    {
        encrypt_p.receiver_num = num_recipients;
        encrypt_p.receivers    = recipients;
    }

    if (optool)
    {
        if ((ophash ? 1 : 0) + (opsign ? 1 : 0) + (opvrfy ? 1 : 0) +
            (opencr ? 1 : 0) + (opdecr ? 1 : 0) + (optssg ? 1 : 0) +
            (opocin ? 1 : 0) > 1)
        {
            print_help = 1;
            goto err;
        }
        if ((msginf ? 1 : 0) + (optsvr ? 1 : 0) > 0)
        {
            print_help = 1;
            goto err;
        }
    }
    else
    {
        if ((ophash ? 1 : 0) + (opsign ? 1 : 0) + (opvrfy ? 1 : 0) +
            (opencr ? 1 : 0) + (opdecr ? 1 : 0) + (msginf ? 1 : 0) +
            (optssg ? 1 : 0) + (optsvr ? 1 : 0) + (opocin ? 1 : 0) != 1)
        {
            print_help = 1;
            goto err;
        }
        if (!finp && (opvrfy ||
                      opencr ||
                      opdecr ||
                      msginf ||
                      optssg ||
                      optsvr ||
                      opocin))
        {
            print_help = 1;
            goto err;
        }
        if (!fout && (opsign ||
                      opencr ||
                      opdecr ||
                      optssg))
        {
            print_help = 1;
            goto err;
        }
        if (!fdat && (ophash ||
                      detached))
        {
            print_help = 1;
            goto err;
        }
        if (fdat && (opencr ||
                     opdecr ||
                     msginf ||
                     optssg ||
                     optsvr ||
                     opocin))
        {
            print_help = 1;
            goto err;
        }
    }

    if (ophash ||
        opvrfy ||
        msginf ||
        optsvr ||
        opocin)
        flag |= FLAG_INIT_USEVERIFYCONTEXT;

    if (sendcert)
    {
        sign_p.flag   |= FLAG_CMS_SIGN_ADDSIGNER;
        verify_p.flag |= FLAG_CMS_VERIFY_REQUIREATTACHEDSIGNER;
    }

    if (!optool && opsign)
        sign_p.flag |= FLAG_CMS_SIGN_CADESBES;

    if (logfile)
    {
#ifdef _WIN32
        flog = fopen(logfile, "acS");
#else
        flog = fopen(logfile, "wa");
#endif
        if (!flog)
        {
#ifdef RUSSIAN
            file_print(stdout, "�訡�� ����㯠 � 䠩�� %s\n", logfile);
#else
            file_print(stdout, "Error opening file %s\n", logfile);
#endif
            rc = VCERT_E_OPEN_OUTFILE;
            goto err;
        }
        fseek(flog, 0, SEEK_END);
    }
    else
        flog = stdout;
#ifdef _VD_DEBUG
    loop:
#endif /* _VD_DEBUG */
    do
    {
        time_t tim = time(NULL);
#ifdef RUSSIAN
        file_print(flog, "\n���樠������: %s", ctime(&tim));
#else
        file_print(flog, "\nInitialization: %s", ctime(&tim));
#endif
    }
    while (0);

#ifdef _LOCAL_
    rc = VCERT_InitMinimal(&hCtx[1]);
    if (rc)
        goto err;

    if (minimal)
        rc = VCERT_InitMinimal(&hCtx[0]);
    else
#endif /* _LOCAL_ */
        rc = VCERT_Initialize(profile, flag, &hCtx[0]);
    if (rc)
        goto err;

#ifdef _LOCAL_
    if (crlupdate)
    {
#ifdef RUSSIAN
        file_print(flog, "���������� ���\n");
#else
        file_print(flog, "CRL update\n");
#endif
        if (critical)
        {
            mem_blk_t error = { sizeof(tmpbuf), (unsigned char *) tmpbuf };

            rc = VCERT_ControlEx(hCtx[0], NULL, VCERT_CMD_UPDATECRLSCRIT, NULL, &error, 0);
            if (rc)
            {
                tmpstr = char_to_oem((const char *) tmpbuf);
#ifdef RUSSIAN
                file_print(flog, "�訡�� ���������� ���: %s\n", tmpstr);
#else
                file_print(flog, "CRL update error: %s\n", tmpstr);
#endif
                if (tmpstr != tmpbuf)
                    free(tmpstr);
            }
        }
        else
            rc = VCERT_UpdateCRLs(hCtx[0]);

        VCERT_GetErrorText(rc, tmpbuf, sizeof(tmpbuf));
        tmpstr = char_to_oem((const char *) tmpbuf);
#ifdef RUSSIAN
        file_print(flog, "������� ���������� ���: %s (%08X)\n", tmpstr, (unsigned int) rc);
#else
        file_print(flog, "CRL update result: %s (%08X)\n", tmpstr, (unsigned int) rc);
#endif
        if (tmpstr != tmpbuf)
            free(tmpstr);
    }
#endif /* _LOCAL_ */

#ifdef _IFACE_
    if (passwd.len && passwd.buf)
    {
        rc = VCERT_Authorize(hCtx[0], &certid, CRSRV_FUNC_SIGN, &passwd);
#if defined(_CCERT_) && !defined(PKI_REQUISITES_CBRF)
        if (rc)
            rc = VCERT_Authorize(hCtx[0], &certid, CRSRV_FUNC_ENCRYPT, &passwd);
        if (rc)
            rc = VCERT_Authorize(hCtx[0], &certid, CRSRV_FUNC_DECRYPT, &passwd);
        if (rc)
            rc = VCERT_Authorize(hCtx[0], &certid, CRSRV_FUNC_ADDCERT, &passwd);
        if (rc)
            rc = VCERT_Authorize(hCtx[0], &certid, CRSRV_FUNC_ADDCRL, &passwd);
#endif /* _CCERT_ && !PKI_REQUISITES_CBRF */
        if (rc)
        {
#ifdef RUSSIAN
            file_print(flog, "\n���ਧ��� �� ��\n");
#else
            file_print(flog, "\nCS authorization\n");
#endif
            goto err;
        }
    }
#endif /* _IFACE_ */

#ifdef _LOCAL_
    if (opencr && (num_recipients <= 0))
    {
        memset(&find_p, 0, sizeof(find_param_t));

        find_p.flag = FLAG_FIND_SHOWUISELECTOR;
        find_p.info = FIELD_ALL;

        rc = VCERT_FindCert(
            hCtx[0],
            &find_p,
            &find_r);

        if (!rc && (find_r.num > 0))
        {
            encrypt_p.receiver_num = find_r.num;
            encrypt_p.receivers    = find_r.certs;
        }
    }
#endif /* _LOCAL_ */

    if (optool)
    {
        rc = tools_main(argc, argv);
    }
    else if (ophash)
    {
#ifdef RUSSIAN
        if (stream)
            file_print(flog, "\n��⮪���� ���᫥��� ���-���祭�� 䠩��\n");
        else
            file_print(flog, "\n���᫥��� ���-���祭�� 䠩��\n");
#else
        file_print(flog, "\n%sCalculate file hash\n", (stream ? "Stream-" : ""));
#endif
        if (stream)
            rc = VCERT_StrHashFile(
                hCtx[0],
                (algorithm ? algorithm : (string_t) "1.2.643.7.1.1.2.2"),
                fdat,
                &hash_r);
        else
            rc = VCERT_BlkHashFile(
                hCtx[0],
                (algorithm ? algorithm : (string_t) "1.2.643.7.1.1.2.2"),
                fdat,
                &hash_r);
    }
    else if (opsign)
    {
#ifdef RUSSIAN
        if (stream)
            file_print(flog, "\n���᫥��� ��⮪���� �� 䠩��\n");
        else
            file_print(flog, "\n���᫥��� �� 䠩��\n");
#else
        file_print(flog, "\n%sSign file\n", (stream ? "Stream-" : ""));
#endif
        if (stream)
        {
            if (detached)
                rc = VCERT_CmsStrDetSignFile(
                    hCtx[0],
                    &sign_p,
                    fdat,
                    finp,
                    fout);
            else
                rc = VCERT_CmsStrAttSignFile(
                    hCtx[0],
                    &sign_p,
                    fdat ? fdat : finp,
                    fout);
        }
        else
            if (detached)
                rc = VCERT_CmsBlkDetSignFile(
                    hCtx[0],
                    &sign_p,
                    fdat,
                    finp,
                    fout);
            else
                rc = VCERT_CmsBlkAttSignFile(
                    hCtx[0],
                    &sign_p,
                    fdat ? fdat : finp,
                    fout);
    }
    else if (opvrfy)
    {
#ifdef RUSSIAN
        if (stream)
            file_print(flog, "\n�஢�ઠ ��⮪���� �� 䠩��\n");
        else
            file_print(flog, "\n�஢�ઠ �� 䠩��\n");
#else
        file_print(flog, "\n%sVerify file\n", (stream ? "Stream-" : ""));
#endif
        if (stream)
        {
            if (detached)
                rc = VCERT_CmsStrDetVerifyFile(
                    hCtx[0],
                    &verify_p,
                    fdat,
                    finp,
                    fout,
                    &verify_r);
            else
                rc = VCERT_CmsStrAttVerifyFile(
                    hCtx[0],
                    &verify_p,
                    finp,
                    fout,
                    &verify_r);
        }
        else
            if (detached)
                rc = VCERT_CmsBlkDetVerifyFile(
                    hCtx[0],
                    &verify_p,
                    fdat,
                    finp,
                    fout,
                    &verify_r);
            else
                rc = VCERT_CmsBlkAttVerifyFile(
                    hCtx[0],
                    &verify_p,
                    finp,
                    fout,
                    &verify_r);
    }
    else if (opencr)
    {
#ifdef RUSSIAN
        if (stream)
            file_print(flog, "\n��⮪���� ����஢���� 䠩��\n");
        else
            file_print(flog, "\n����஢���� 䠩��\n");
#else
        file_print(flog, "\n%sEncrypt file\n", (stream ? "Stream-" : ""));
#endif
        if (stream)
            rc = VCERT_CmsStrEncryptFile(
                hCtx[0],
                &encrypt_p,
                finp,
                fout);
        else
            rc = VCERT_CmsBlkEncryptFile(
                hCtx[0],
                &encrypt_p,
                finp,
                fout);
    }
    else if (opdecr)
    {
#ifdef RUSSIAN
        if (stream)
            file_print(flog, "\n��⮪���� ����஢���� 䠩��\n");
        else
            file_print(flog, "\n�����஢���� 䠩��\n");
#else
        file_print(flog, "\n%sDecrypt file\n", (stream ? "Stream-" : ""));
#endif
        if (stream)
            rc = VCERT_CmsStrDecryptFile(
                hCtx[0],
                &decrypt_p,
                finp,
                fout,
                &decrypt_r);
        else
            rc = VCERT_CmsBlkDecryptFile(
                hCtx[0],
                &decrypt_p,
                finp,
                fout,
                &decrypt_r);
    }
    else if (msginf)
    {
#ifdef RUSSIAN
        if (stream)
            file_print(flog, "\n��⮪���� ����祭�� ���ଠ樨 � CMS ᮮ�饭��\n");
        else
            file_print(flog, "\n����祭�� ���ଠ樨 � CMS ᮮ�饭��\n");
#else
        file_print(flog, "\n%sCMS message information\n", (stream ? "Stream-" : ""));
#endif
        if (stream)
            rc = VCERT_CmsStrMsgInfFile(
                hCtx[0],
                finp,
                &msginf_r,
                0);
        else
            rc = VCERT_CmsBlkMsgInfFile(
                hCtx[0],
                finp,
                &msginf_r,
                0);
    }
    else if (optssg)
    {
#ifdef RUSSIAN
        if (stream)
            file_print(flog, "\n��⮪���� ����祭�� �⠬�� �६���\n");
        else
            file_print(flog, "\n����祭�� �⠬�� �६���\n");
#else
        file_print(flog, "\n%sTime stamp signing\n", (stream ? "Stream-" : ""));
#endif
        if (stream)
            rc = VCERT_TspStrUrlStampCmsFile(
                hCtx[0],
                &tssign_p,
                url,
                finp,
                fout);
        else
            rc = VCERT_TspBlkUrlStampCmsFile(
                hCtx[0],
                &tssign_p,
                url,
                finp,
                fout);
    }
    else if (optsvr)
    {
#ifdef RUSSIAN
        if (stream)
            file_print(flog, "\n��⮪���� �஢�ઠ �⠬�� �६���\n");
        else
            file_print(flog, "\n�஢�ઠ �⠬�� �६���\n");
#else
        file_print(flog, "\n%sTime stamp verification\n", (stream ? "Stream-" : ""));
#endif
        if (stream)
            rc = VCERT_TspStrVerifyCmsFile(
                hCtx[0],
                &tsverif_p,
                finp,
                &tsverif_r);
        else
            rc = VCERT_TspBlkVerifyCmsFile(
                hCtx[0],
                &tsverif_p,
                finp,
                &tsverif_r);
    }
    else if (opocin)
    {
        mem_blk_t bcer   = { 0 };
        mem_blk_t bres   = { 0 };
        FILE      * fcer = NULL;

#ifdef RUSSIAN
        file_print(flog, "\n����祭�� OCSP ����� ���䨪��\n");
#else
        file_print(flog, "\nCertificate OCSP status verification\n");
#endif

        fcer = fopen(finp, "rb");
        if (!fcer)
        {
            rc = VCERT_E_OPEN_INFILE;
            goto err;
        }

        fseek(fcer, 0, SEEK_END),
            bcer.len = (unsigned int) ftell(fcer),
                fseek(fcer, 0, SEEK_SET);

        bcer.buf = VCERT_AllocMem(hCtx[0], bcer.len);
        if (!bcer.buf)
        {
            rc = VCERT_E_NO_MEMORY,
                fclose(fcer);
            goto err;
        }

        if (fread(bcer.buf, 1, (size_t) bcer.len, fcer) != (size_t) bcer.len)
        {
            rc = VCERT_E_READ_FILE,
                VCERT_FreeMem(hCtx[0], bcer.buf), fclose(fcer);
            goto err;
        }

        rc = VCERT_OcspUrlObtainResponse(
            hCtx[0],
            &ocspsig_p,
            url,
            &bcer,
            &bres);

        VCERT_FreeMem(hCtx[0], bcer.buf), fclose(fcer);

        if (rc)
            goto err;

        rc = VCERT_OcspVerifyResponse(
            hCtx[0],
            &ocspver_p,
            &bres,
            &ocspver_r);

        VCERT_FreeMem(hCtx[0], bres.buf);
    }

 err:
    if (!print_help)
    {
        if (ophash && !rc)
        {
            switch (format)
            {
            case 1:
            default:
                for (idx = 0; idx < (int) hash_r.len; idx ++)
                    file_print(flog, "%02X", ((hash_r.buf[idx] << 4) & 0xF0) |
                                             ((hash_r.buf[idx] >> 4) & 0x0F));
                break;
            case 2:
                for (idx = 0; idx < (int) hash_r.len; idx ++)
                    file_print(flog, "%02X", hash_r.buf[idx]);
                break;
            case 3:
                for (idx = (int) hash_r.len; idx > 0; idx --)
                    file_print(flog, "%02X", hash_r.buf[idx - 1]);
                break;
#ifdef _LOCAL_
            case 4:
                if (SUCCEEDED(VCERT_EncodeMem((byte *) tmpbuf, hash_r.buf, hash_r.len)))
                    file_print(flog, "%s", tmpbuf);
                break;
#endif /* _LOCAL_ */
            }
            file_print(flog, "\n");
        }

        if (opvrfy)
        {
            for (idx = 0; idx < (int) verify_r.sign_num; idx ++)
            {
                time_t tim = (time_t) verify_r.signs[idx].time;
                VCERT_GetErrorText(verify_r.signs[idx].status, tmpbuf, sizeof(tmpbuf));
                tmpstr = char_to_oem((const char *) tmpbuf);
#ifdef RUSSIAN
                file_print(flog, "\n�� [% 3d]: %s (%08X)\n%s", idx + 1,
                           tmpstr, verify_r.signs[idx].status, tim ? ctime(&tim) : "-\n");
#else
                file_print(flog, "\nSignature [% 3d]: %s (%08X)\n%s", idx + 1,
                           tmpstr, verify_r.signs[idx].status, tim ? ctime(&tim) : "-\n");
#endif
                if (tmpstr != tmpbuf)
                    free(tmpstr);
                if (verify_r.signs[idx].cert && verify_r.signs[idx].cert->fields)
                {
                    if (policy_p.check_time > 0)
                    {
                        error_status_t cpr = VCERT_VerifyCertificatePolicy(hCtx[0], &policy_p,
                                                                           &verify_r.signs[idx].cert->certEncoded);
                        VCERT_GetErrorText(cpr, tmpbuf, sizeof(tmpbuf));
                        tmpstr = char_to_oem((const char *) tmpbuf);
#ifdef RUSSIAN
                        file_print(flog, "������� �஢�ન 楯�窨..: %s (%08X)\n", tmpstr, cpr);
#else
                        file_print(flog, "Chain verification result...: %s (%08X)\n", tmpstr, cpr);
#endif
                        if (tmpstr != tmpbuf)
                            free(tmpstr);
                    }
                    certificate_print(flog, verify_r.signs[idx].cert);
                }
                file_print(flog, "\n");
            }
        }

        if (opdecr && !rc)
        {
            certificate_print(flog, &decrypt_r.sender);
            file_print(flog, "\n");
        }

        if (msginf && !rc)
        {
            msginf_print(flog, &msginf_r);
            file_print(flog, "\n");
        }

        if (optsvr)
        {
            time_t tim = (time_t) tsverif_r.time;
            if (tim)
#ifdef RUSSIAN
                file_print(flog, "\n�⠬� �६���: [POSIX: %d] %s\n", (date_t) tim, ctime(&tim));
#else
                file_print(flog, "\nTime stamp: [POSIX: %d] %s\n", (date_t) tim, ctime(&tim));
#endif
            if (tsverif_r.cert && tsverif_r.cert->fields)
            {
                certificate_print(flog, tsverif_r.cert);
                file_print(flog, "\n");
            }
        }

        if (opocin && ocspver_r.status != -1)
        {
            time_t trv = (time_t) ocspver_r.revtime;
            time_t tth = (time_t) ocspver_r.thisupd;
            time_t tnx = (time_t) ocspver_r.nextupd;
#ifdef RUSSIAN
            file_print(flog, "\n����� ���䨪��: %d [��稭�: %d]\n", ocspver_r.status, ocspver_r.reason);
#else
            file_print(flog, "\nCertificate status: %d [reason: %d]\n", ocspver_r.status, ocspver_r.reason);
#endif
            if (trv)
#ifdef RUSSIAN
                file_print(flog, "�६� ���㫨஢��.: %s", ctime(&trv));
#else
                file_print(flog, "Revocation time...: %s", ctime(&trv));
#endif
            if (tth)
#ifdef RUSSIAN
                file_print(flog, "�६� ᮧ����� ��.: %s", ctime(&tth));
#else
                file_print(flog, "Signing time......: %s", ctime(&tth));
#endif
            if (tnx)
#ifdef RUSSIAN
                file_print(flog, "�६� ����⢨�....: %s", ctime(&tnx));
#else
                file_print(flog, "Next update.......: %s", ctime(&tnx));
#endif
            file_print(flog, "\n");
            if (ocspver_r.cert && ocspver_r.cert->fields)
            {
                certificate_print(flog, ocspver_r.cert);
                file_print(flog, "\n");
            }
        }

        status_print(flog, rc, -1);
    }

    if (flog && (stdout != flog))
        fclose(flog);

    VCERT_FreeMem(hCtx[0], hash_r.buf);

    VCERT_FreeVerifyResult(hCtx[0], &verify_r);

    VCERT_FreeDecryptResult(hCtx[0], &decrypt_r);

    VCERT_CmsFreeMsgInf(hCtx[0], &msginf_r);

    VCERT_TspFreeVerifyResult(hCtx[0], &tsverif_r);

    VCERT_OcspFreeVerifyResult(hCtx[0], &ocspver_r);

    VCERT_FreeFindResult(hCtx[0], &find_r);

    VCERT_Uninitialize(hCtx[0]);
#ifdef _LOCAL_
    VCERT_Uninitialize(hCtx[1]);
#endif /* _LOCAL_ */
#ifdef _VD_DEBUG
    goto loop;
#endif /* _VD_DEBUG */
    if (num_recipients)
    {
        for (idx = 0; idx < num_recipients; idx ++)
        {
            switch (recipients[idx].fields)
            {
            case FIELD_CERTHASH:
                if (recipients[idx].certHash.buf)
                    free(recipients[idx].certHash.buf);
                break;

            case FIELD_KEYID:
                if (recipients[idx].keyId)
                    free(recipients[idx].keyId);
                break;

            case FIELD_SUBJECT:
                if (recipients[idx].subject)
                    free(recipients[idx].subject);
                break;

            case FIELD_SUBJECTALTNAME:
                if (recipients[idx].subjectAltName.emailAddress)
                    free(recipients[idx].subjectAltName.emailAddress);
            }
        }
    }

    if (print_help && !optool)
    {
#ifdef RUSSIAN
        file_print(stdout, "�⨫�� ��������� ��ப� (����� %d.%d.%03d.%d)", VER_BUILDMAJOR, VER_BUILDMINOR, VER_BUILDNUMBER, VER_BUILDQFE);
        file_print(stdout, " �ᯮ�짮�����:\n");
        file_print(stdout, "  %s [��������] [���������] [�����]\n", argv[0]);
        file_print(stdout, "����樨:\n");
        file_print(stdout, "  -hash               ���᫥��� ���-���祭�� 䠩��\n");
        file_print(stdout, "  -sign               ���᫥��� �� 䠩��\n");
        file_print(stdout, "  -verify             �஢�ઠ �� 䠩��\n");
        file_print(stdout, "  -encrypt            ����஢���� 䠩��\n");
        file_print(stdout, "  -decrypt            ����஢���� 䠩��\n");
        file_print(stdout, "  -msginf             ����祭�� ���ଠ樨 � CMS ᮮ�饭��\n");
        file_print(stdout, "  -tssign             ����祭�� �⠬�� �६���\n");
        file_print(stdout, "  -tsverif            �஢�ઠ �⠬�� �६���\n");
        file_print(stdout, "  -ocspinf            ����祭�� ����� ���䨪��\n");
        file_print(stdout, "  -tools              �ᯮ�짮����� ���७��� ���������⥩\n");
        file_print(stdout, "  -help               ����� �ࠢ�� �� �⨫��\n");
        file_print(stdout, "��ࠬ����:\n");
        file_print(stdout, "  -profile [PROFILE]  ��⠭����� ��� ��䨫� � PROFILE\n");
#ifdef _LOCAL_
        file_print(stdout, "  -registry           �ᯮ�짮���� ����ன�� ��䨫�� ��ࠢ�筨��\n");
#endif /* _LOCAL_ */
#ifdef _IFACE_
        file_print(stdout, "  -alias [ALIAS]      ��⠭����� �����䨪��� ��ᨨ �� � ALIAS\n");
        file_print(stdout, "  -auth [PASSWORD]    ��⠭����� ����� ���ਧ�樨 �� �� � PASSWORD\n");
#endif /* _IFACE_ */
        file_print(stdout, "  -algorithm [OID]    ��ꥪ�� �����䨪��� �����⬠ ���஢����\n");
        file_print(stdout, "  -in [INFILE]        ��� �室���� 䠩�� INFILE\n");
        file_print(stdout, "  -out [OUTFILE]      ��� ��室���� 䠩�� OUTFILE\n");
        file_print(stdout, "  -data [DATAFILE]    ��� 䠩�� ������ DATAFILE (��� �� � ���-���祭��)\n");
        file_print(stdout, "��樨:\n");
#ifdef _LOCAL_
        file_print(stdout, "  -minimal            �ᯮ�짮���� ��������� ����� �㭪権\n");
#endif /* _LOCAL_ */
        file_print(stdout, "  -stream             �ᯮ�짮���� ��⮪��� �ਯ⮣���᪨� �㭪樨\n");
#ifdef _LOCAL_
        file_print(stdout, "  -format [FMT]       �ଠ� ���-���祭�� - 1: LE �᫮ (�� 㬮�砭��); 2: LE �����; 3: BE �᫮; 4: Base64\n");
#endif /* _LOCAL_ */
#ifdef _IFACE_
        file_print(stdout, "  -format [FMT]       �ଠ� ���-���祭�� - 1: LE �᫮ (�� 㬮�砭��); 2: LE �����; 3: BE �᫮\n");
#endif /* _IFACE_ */
        file_print(stdout, "  -silent [ERRFILE]   ०�� ��� ������ ᮮ�饭�� � ������� ��⮪��� � ERRFILE\n");
        file_print(stdout, "  -sendcert           ���������/�ॡ����� ������ ���䨪�� �����ᠭ� �� ���᫥���/�஢�થ ��\n");
#ifdef _LOCAL_
        file_print(stdout, "  -crlupdate          ���筮� ���������� ��� �� �祪 �����࠭����\n");
        file_print(stdout, "  -critical           ���筮� ���������� ��� �� �祪 �����࠭���� (�ॡ�� -crlupdate)\n");
#endif /* _LOCAL_ */
        file_print(stdout, "  -url [URL]          ���� �ࢥ� �⠬��� �६��� ��� �ࢥ� ����� ���䨪�⮢, URI �ࠢ�筨��\n");
        file_print(stdout, "  -index [IDX]        ������ �� �⠬�� �६��� >= 1 (�� 㬮�砭��)\n");
        file_print(stdout, "��樨 �஢�ન ��:\n");
        file_print(stdout, "  -revtime            �ᯮ�짮���� �६� ���㫨஢���� ���䨪��\n");
        file_print(stdout, "  -detached           ������ ��ᮥ������� �ଠ� ��\n");
        file_print(stdout, "  -eku [EKU]          �������� OID EKU ���७���� �ᯮ�짮����� ����\n");
        file_print(stdout, "  -policy [POLICY]    �������� OID POLICY ॣ������ �ᯮ�짮����� ���䨪��\n");
        file_print(stdout, "  -delete [���]       㤠���� ��� �� (� ����) ��᫥ �஢�ન\n");
#ifdef _LOCAL_
        file_print(stdout, "  -ldap               ������� ����������� ���᪠ ���䨪�⮢ � ���\n");
        file_print(stdout, "  -aiacdp             �ᯮ�짮���� �窨 AIA � CDP �� ����஥��� 楯�祪\n");
#endif /* _LOCAL_ */
        file_print(stdout, "  -info [FIELDS]      �뢮����� ���ଠ�� � ���䨪�� (�� 㬮�砭��: ��������, ���)\n");
        file_print(stdout, "  �������� ���祭��: serial, issuer, subject, notbefore, notafter, altname, keyid, certhash, algorithm, all\n");
        file_print(stdout, "  -vertime [SIGTM]    �஢����� 楯��� ���䨪�� �� ������� ������ �६���\n");
        file_print(stdout, "��樨 ��஢����:\n");
        file_print(stdout, "  -recsubj [SUBJ]     �������� ���䨪�� � ������ �������� SUBJ � ᯨ᮪ �����⥫��\n");
        file_print(stdout, "  -rechash [HASH]     �������� ���䨪�� � ��襬 ����⥫�/��. ����� HASH � ᯨ᮪ �����⥫��\n");
        file_print(stdout, "  -reckeyid [KEYID]   �������� ���䨪�� � �����䨪��஬ ���� KEYID � ᯨ᮪ �����⥫��\n");
#ifdef _WIN32
        file_print(stdout, "  -reclist [FILE]     ����� ᯨ᮪ �����⥫�� �� 䠩�� FILE\n");
#endif
        file_print(stdout, "  -partial            ����� �������楢 ���䨪�⮢ �����⥫�� ������ ���筮\n");
        file_print(stdout, "  -nolocal            �᪫���� ���� ���䨪�⮢ � �࠭���� ���\n");
        file_print(stdout, "  -nocache            �᪫���� ���� ���䨪�⮢ � �࠭���� ���\n");
        file_print(stdout, "  -attrib             �ᯮ�짮���� ���� �� ���祭�� ��ਡ�� vdSubjName ���\n");
        file_print(stdout, "  -1215mg             ����஢뢠�� CMS ᮮ�饭�� �� ���� � 34.12-2015 �����\n");
        file_print(stdout, "  -1215gh             ����஢뢠�� CMS ᮮ�饭�� �� ���� � 34.12-2015 �㧭�稪\n");
        file_print(stdout, "  -1215mac            ������� � ��������� ���⮢�⠢�� � ����஢����� CMS ᮮ�饭��\n");
        file_print(stdout, "  -keyagree           ᮧ������ � CMS ᮮ�饭�� �����⥫�� ⨯� KeyAgreement\n");
#else  /* RUSSIAN */
        file_print(stdout, "Command-line utility (%d.%d.%03d.%d)", VER_BUILDMAJOR, VER_BUILDMINOR, VER_BUILDNUMBER, VER_BUILDQFE);
        file_print(stdout, " usage:\n");
        file_print(stdout, "  %s [OPERATIONS] [OPTIONS] [SUB-OPTIONS]\n", argv[0]);
        file_print(stdout, "operations:\n");
        file_print(stdout, "  -hash               calculate file hash\n");
        file_print(stdout, "  -sign               sign file\n");
        file_print(stdout, "  -verify             verify file\n");
        file_print(stdout, "  -encrypt            encrypt file\n");
        file_print(stdout, "  -decrypt            decrypt file\n");
        file_print(stdout, "  -msginf             CMS message information\n");
        file_print(stdout, "  -tssign             time stamp signing\n");
        file_print(stdout, "  -tsverif            time stamp verification\n");
        file_print(stdout, "  -ocspinf            online certificate status\n");
        file_print(stdout, "  -tools              use advanced capabilities\n");
        file_print(stdout, "  -help               print help\n");
        file_print(stdout, "options:\n");
        file_print(stdout, "  -profile [PROFILE]  set profile name to PROFILE\n");
#ifdef _LOCAL_
        file_print(stdout, "  -registry           use Certificate Store profile configuration\n");
#endif /* _LOCAL_ */
#ifdef _IFACE_
        file_print(stdout, "  -alias [ALIAS]      set CryptoServer session identifier to ALIAS\n");
        file_print(stdout, "  -auth [PASSWORD]    set CryptoServer authorization data to PASSWORD\n");
#endif /* _IFACE_ */
        file_print(stdout, "  -algorithm [OID]    hash algorithm object identifier\n");
        file_print(stdout, "  -in [INFILE]        set input file to INFILE\n");
        file_print(stdout, "  -out [OUTFILE]      set output file to OUTFILE\n");
        file_print(stdout, "  -data [DATAFILE]    set data file to DATAFILE\n");
        file_print(stdout, "sub-options:\n");
#ifdef _LOCAL_
        file_print(stdout, "  -minimal            use minimal function set\n");
#endif /* _LOCAL_ */
        file_print(stdout, "  -stream             use streaming cryptographic functions\n");
#ifdef _LOCAL_
        file_print(stdout, "  -format [FMT]       hash value format - 1: LE number (default); 2: LE bytes; 3: BE number; 4: Base64\n");
#endif /* _LOCAL_ */
#ifdef _IFACE_
        file_print(stdout, "  -format [FMT]       hash value format - 1: LE number (default); 2: LE bytes; 3: BE number\n");
#endif /* _IFACE_ */
        file_print(stdout, "  -silent [ERRFILE]   silent mode with logging to ERRFILE\n");
        file_print(stdout, "  -sendcert           add/require signer's certificate when signing/verifying\n");
#ifdef _LOCAL_
        file_print(stdout, "  -crlupdate          regular CRL update from Distribution Points\n");
        file_print(stdout, "  -critical           critical CRL update from Distribution Points (use with -crlupdate)\n");
#endif /* _LOCAL_ */
        file_print(stdout, "  -url [URL]          time stamp or online certificate status server URL, certificate store URI\n");
        file_print(stdout, "  -index [IDX]        time stamp signature index >= 1 (default)\n");
        file_print(stdout, "verification options:\n");
        file_print(stdout, "  -revtime            use certificate revocation time\n");
        file_print(stdout, "  -detached           set detached signature format\n");
        file_print(stdout, "  -eku [EKU]          add OID EKU to verify extended key usage (< %d)\n", MAX_NUM);
        file_print(stdout, "  -policy [POLICY]    add OID POLICY to verify certificate policy (< %d)\n", MAX_NUM);
        file_print(stdout, "  -delete [NUM]       delete NUM trailing signatures\n");
#ifdef _LOCAL_
        file_print(stdout, "  -ldap               use NCS to for certificate searches\n");
        file_print(stdout, "  -aiacdp             use AIA and CDP information for chain building\n");
#endif /* _LOCAL_ */
        file_print(stdout, "  -info [FIELDS]      certificate information (default: subject, hash)\n");
        file_print(stdout, "  possible fields: serial, issuer, subject, notbefore, notafter, altname, keyid, certhash, algorithm, all\n");
        file_print(stdout, "  -vertime [SIGTM]    verify certificate chain at the supplied time value\n");
        file_print(stdout, "encryption options:\n");
        file_print(stdout, "  -recsubj [SUBJ]     add certificate identified by SUBJ to recipients (< %d)\n", MAX_NUM);
        file_print(stdout, "  -rechash [HASH]     add certificate identified by HASH to recipients (< %d)\n", MAX_NUM);
        file_print(stdout, "  -reckeyid [KEYID]   add certificate identified by KEYID to recipients (< %d)\n", MAX_NUM);
#ifdef _WIN32
        file_print(stdout, "  -reclist [FILE]     read list of recipients from FILE\n");
#endif
        file_print(stdout, "  -partial            recipient certificates' subjects are partialy set\n");
        file_print(stdout, "  -nolocal            do not search for certificates in local store\n");
        file_print(stdout, "  -nocache            do not search for certificates in cache\n");
        file_print(stdout, "  -attrib             search by NCS container attribute vdSubjName\n");
        file_print(stdout, "  -1215mg             encrypt CMS message with GOST R 34.12-2015 Magma\n");
        file_print(stdout, "  -1215gh             encrypt CMS message with GOST R 34.12-2015 Kuznyechik\n");
        file_print(stdout, "  -1215mac            calculate and add MAC to the CMS message being encrypted\n");
        file_print(stdout, "  -keyagree           create KeyAgreement CMS message recipient structures\n");
#endif /* RUSSIAN */
    }

    if (print_help && optool)
    {
#ifdef RUSSIAN
        file_print(stdout, "\n����७�� - �⨫�� ��������� ��ப� (����� %d.%d.%03d.%d)", VER_BUILDMAJOR, VER_BUILDMINOR, VER_BUILDNUMBER, VER_BUILDQFE);
        file_print(stdout, " �ᯮ�짮�����:\n");
        file_print(stdout, "  %s -tools [��������] [���������] [�����]\n", argv[0]);
        file_print(stdout, "����樨:\n");
        file_print(stdout, "  -attach             ��ᮥ������� �� � �������ᠭ���� 䠩��\n");
        file_print(stdout, "  -detach             ��ᮥ������� �� �� �����ᠭ���� 䠩��\n");
        file_print(stdout, "  -enuobj             ��ॡ�� ��ꥪ⮢ �ࠢ�筨���\n");
        file_print(stdout, "  -findcer            ���� ���䨪�⮢ � �ࠢ�筨���\n");
        file_print(stdout, "  -speed              �믮������ ᪮��⭮�� ���\n");
        file_print(stdout, "  �஢��塞�� ������: -hash, -sign, -verify, -encrypt, -decrypt, -findcert\n");
#ifdef _LOCAL_
        file_print(stdout, "  -enuprof            ��ॡ�� ����஥���� ��䨫��\n");
        file_print(stdout, "  -creprof            ᮧ����� ��� ����䨪��� ��䨫�\n");
        file_print(stdout, "  -crestor            ᮧ����� �࠭���� ��� � ��� �� �������� ���䨪�⮢ � ���\n");
        file_print(stdout, "  -impobj             ������ ���䨪��, ���, ��� ���������� �� �� ��� ��\n");
        file_print(stdout, "  -expreq             ��ᯮ�� ����� PKCS#10 ��� ����� �� ���㫨஢���� ���䨪��\n");
#endif /* _LOCAL_ */
#ifdef _IFACE_
        file_print(stdout, "  -impobj             ������ ���䨪�� ��� ���\n");
#endif /* _IFACE_ */
        file_print(stdout, "��ࠬ����:\n");
        file_print(stdout, "  -query [QUERY]      �����᪮� ��ࠦ���� ��� ��ॡ�� ��ꥪ⮢ � ���\n");
        file_print(stdout, "  -subject [SUBJ]     ��� �������� �᪮���� ���䨪��\n");
        file_print(stdout, "  -issuer [ISSU]      ��� ����⥫� �᪮���� ���䨪��\n");
        file_print(stdout, "  -serial [SERIAL]    �਩�� ����� �᪮���� ���䨪��\n");
        file_print(stdout, "  -cerhash [HASH]     ��� ����⥫�/��. ����� �᪮���� ���䨪��\n");
        file_print(stdout, "  -email [EMAIL]      ���� �����஭��� ����� �᪮���� ���䨪��\n");
        file_print(stdout, "  -keyid [KEYID]      �����䨪��� ���� �� �᪮���� ���䨪��\n");
        file_print(stdout, "  -subjkid [SKID]     �����䨪��� ���� �������� �᪮���� ���䨪��\n");
        file_print(stdout, "��樨 ᪮��⭮�� ���:\n");
        file_print(stdout, "  -iterat [ITER]      ������⢮ ����७�� ����樨 ᪮��⭮�� ���\n");
        file_print(stdout, "  -threads [THRS]     ������⢮ ��⮪�� �믮������ ᪮��⭮�� ���\n");
#ifdef _LOCAL_
        file_print(stdout, "��樨 ��䨫��:\n");
        file_print(stdout, "  -uripse [PSE]       ���� � �࠭����� ���䨪�⮢ ���\n");
        file_print(stdout, "  -uriloc [LOCAL]     ���� � �࠭����� ���䨪�⮢ ���\n");
        file_print(stdout, "  -urildp [LDAP]      ���� � �࠭����� ���䨪�⮢ ���\n");
        file_print(stdout, "  -dercer [FCER]      ���� � 䠩�� ���䨪�� � DER- ��� PEM-�ଠ�\n");
        file_print(stdout, "  -dercrl [FCRL]      ���� � 䠩�� ��� � DER- ��� PEM-�ଠ�\n");
#endif /* _LOCAL_ */
        file_print(stdout, "��樨 ������ � ��ᯮ��:\n");
#ifdef _LOCAL_
        file_print(stdout, "  -showui             �⮡ࠦ��� ��������� ����䥩� ������ ��ꥪ�\n");
        file_print(stdout, "  -signer             ��⠭����� ࠡ�稩 ���䨪�� ���짮��⥫�\n");
#endif /* _LOCAL_ */
        file_print(stdout, "  -remote             �ਭ㤨⥫쭮 ������஢��� ��ꥪ� � ���\n");
#ifdef _LOCAL_
        file_print(stdout, "  -512bit             �ନ஢��� ���� �� �� ���� � 34.10-2012 512 ��� (�� 㬮�砭��: 256 ���)\n");
        file_print(stdout, "  -cargen             �ନ஢��� ���� �� ����� vdToken (���) � ���\n");
        file_print(stdout, "  -revoke             �ନ஢��� ����� �� ���㫨஢���� ���䨪��\n");
#endif /* _LOCAL_ */
#else  /* RUSSIAN */
        file_print(stdout, "\nAdvanced - Command-line utility (%d.%d.%03d.%d)", VER_BUILDMAJOR, VER_BUILDMINOR, VER_BUILDNUMBER, VER_BUILDQFE);
        file_print(stdout, " usage:\n");
        file_print(stdout, "  %s -tools [OPERATIONS] [OPTIONS] [SUB-OPTIONS]\n", argv[0]);
        file_print(stdout, "operations:\n");
        file_print(stdout, "  -attach             attach signature(s) to unsigned file\n");
        file_print(stdout, "  -detach             detach signature(s) from signed file\n");
        file_print(stdout, "  -enuobj             store object enumeration\n");
        file_print(stdout, "  -findcer            store certificate search\n");
        file_print(stdout, "  -speed              speed test execution\n");
        file_print(stdout, "  specify operation: -hash, -sign, -verify, -encrypt, -decrypt, -findcert\n");
#ifdef _LOCAL_
        file_print(stdout, "  -enuprof            configured profile enumeration\n");
        file_print(stdout, "  -creprof            profile creation or modification\n");
        file_print(stdout, "  -crestor            create PSE and LCS stores with given certificates and CRLs\n");
        file_print(stdout, "  -impobj             import certificate, CRL, or CA- or RA-signed update\n");
        file_print(stdout, "  -expreq             export PKCS#10 request or certificate revocation request\n");
#endif /* _LOCAL_ */
#ifdef _IFACE_
        file_print(stdout, "  -impobj             import certificate or CRL\n");
#endif /* _IFACE_ */
        file_print(stdout, "options:\n");
        file_print(stdout, "  -query [QUERY]      logical expression for LDAP object enumeration\n");
        file_print(stdout, "  -subject [SUBJ]     certificate subject name\n");
        file_print(stdout, "  -issuer [ISSU]      certificate issuer name\n");
        file_print(stdout, "  -serial [SERIAL]    certificate serial number\n");
        file_print(stdout, "  -cerhash [HASH]     certificate issuer/serial hash\n");
        file_print(stdout, "  -email [EMAIL]      certificate email address\n");
        file_print(stdout, "  -keyid [KEYID]      certificate private key identifier\n");
        file_print(stdout, "  -subjkid [SKID]     certificate subject key identifier\n");
        file_print(stdout, "speed test options:\n");
        file_print(stdout, "  -iterat [ITER]      number of speed test iterations\n");
        file_print(stdout, "  -threads [THRS]     number of speed test execution threads\n");
#ifdef _LOCAL_
        file_print(stdout, "profile options:\n");
        file_print(stdout, "  -uripse [PSE]       PSE certificate store path\n");
        file_print(stdout, "  -uriloc [LOCAL]     LCS certificate store path\n");
        file_print(stdout, "  -urildp [LDAP]      NCS certificate store path\n");
        file_print(stdout, "  -dercer [FCER]      DER- or PEM-certificate file path\n");
        file_print(stdout, "  -dercrl [FCRL]      DER- or PEM-CRL file path\n");
#endif /* _LOCAL_ */
        file_print(stdout, "import and export options:\n");
#ifdef _LOCAL_
        file_print(stdout, "  -showui             display object details user interface\n");
        file_print(stdout, "  -signer             install user signer certificate\n");
#endif /* _LOCAL_ */
        file_print(stdout, "  -remote             force object import into NCS\n");
#ifdef _LOCAL_
        file_print(stdout, "  -512bit             generate GOST R 34.10-2012 512 bit private key (default: 256 bit)\n");
        file_print(stdout, "  -cargen             generate private key inside vdToken (FKC) using RNG\n");
        file_print(stdout, "  -revoke             generate certificate revocation request\n");
#endif /* _LOCAL_ */
#endif /* RUSSIAN */
    }

    return rc;
}

#ifdef _WIN32

#else  /* _WIN32 */

#ifdef _VD_DEBUG

/* #define _VD_DBG_MMAP */
/* #define _VD_DBG_NULL */

#include <errno.h>
#include <dlfcn.h>
#include <limits.h>
#include <sys/mman.h>

typedef struct _vd_mem_blk
{
    unsigned int uiMask1;
    unsigned int uiLeng1;
    unsigned int uiMask2;
    unsigned int uiLeng2;
} vd_mem_blk;

static size_t s_stBaseAddr = 0x0000100000000000;
static size_t s_stPageSize = 0x0000000000001000;

static void *
__vd_alloc(
    size_t size,
    void * addr)
{
#ifdef _VD_DBG_MMAP

    void   * pvBlkPtr;
    void   * pvTmpPtr;
    size_t stBlkSize;

#endif /* _VD_DBG_MMAP */

    if (size > (size_t) UINT_MAX)
    {
        abort();
    }

#ifdef _VD_DBG_NULL

    do
    {
        Dl_info AddrInf = { 0 };

        if (dladdr(addr, &AddrInf) != 0 && strstr(AddrInf.dli_fname, "libdcerpc.so.1") != NULL)
        {
            if (((unsigned int) rand() % 1009) == 0)
            {
                return NULL;
            }
        }
    }
    while (0);

#endif /* _VD_DBG_NULL */

#ifdef _VD_DBG_MMAP

    stBlkSize = sizeof(vd_mem_blk) + size;
    stBlkSize = (stBlkSize + s_stPageSize - 1) & ~(s_stPageSize - 1);

    pvBlkPtr = (void *) __sync_fetch_and_add(&s_stBaseAddr, stBlkSize);
    pvBlkPtr = mmap(pvTmpPtr = pvBlkPtr, stBlkSize, PROT_READ | PROT_WRITE,
                    MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    if (pvBlkPtr == (void *) (size_t) MAP_FAILED)
    {
        printf("__vd_alloc(): mmap(%p, %p) failed: %d\n", pvTmpPtr, (void *) stBlkSize, errno);
        abort();
    }

    ((vd_mem_blk *) pvBlkPtr)->uiMask1 = 0x5a5a5a5a;
    ((vd_mem_blk *) pvBlkPtr)->uiLeng1 = (unsigned int) (size) ^ 0x5a5a5a5a;

    ((vd_mem_blk *) pvBlkPtr)->uiMask2 = 0xa5a5a5a5;
    ((vd_mem_blk *) pvBlkPtr)->uiLeng2 = (unsigned int) (size) ^ 0xa5a5a5a5;

    memset((char *) pvBlkPtr + sizeof(vd_mem_blk) + size, 0xf0,
                   stBlkSize - sizeof(vd_mem_blk) - size);

    return (char *) pvBlkPtr + sizeof(vd_mem_blk);

#else  /* _VD_DBG_MMAP */

    extern void *
    __libc_calloc(
        size_t nmemb,
        size_t size);

    return __libc_calloc(1, size);

#endif /* _VD_DBG_MMAP */
}

static void
__vd_free(
    void * ptr)
{
#ifdef _VD_DBG_MMAP

    void   * pvBlkPtr = (char *) ptr - sizeof(vd_mem_blk);
    size_t stBlkSize;

    if (ptr != NULL)
    {
        if (((vd_mem_blk *) pvBlkPtr)->uiMask1 != 0x5a5a5a5a ||
            ((vd_mem_blk *) pvBlkPtr)->uiMask2 != 0xa5a5a5a5)
        {
            abort();
        }

        if ((stBlkSize = (((vd_mem_blk *) pvBlkPtr)->uiLeng1 ^ 0x5a5a5a5a)) !=
                         (((vd_mem_blk *) pvBlkPtr)->uiLeng2 ^ 0xa5a5a5a5))
        {
            abort();
        }

        for (stBlkSize = sizeof(vd_mem_blk) + stBlkSize;
             stBlkSize < ((stBlkSize + s_stPageSize - 1) & ~(s_stPageSize - 1));
             stBlkSize ++)
        {
            if (*((char *) pvBlkPtr + stBlkSize) != (char) 0xf0)
            {
                abort();
            }
        }

        if (munmap(pvBlkPtr, stBlkSize) == (int) (size_t) MAP_FAILED)
        {
            printf("__vd_free(): munmap(%p, %p) failed: %d\n", pvBlkPtr, (void *) stBlkSize, errno);
            abort();
        }
    }

#else  /* _VD_DBG_MMAP */

    extern void *
    __libc_free(
        void * ptr);

    __libc_free(ptr);

#endif /* _VD_DBG_MMAP */
}

extern void *
malloc(
    size_t size)
{
    void * pvBlkPtr = __vd_alloc(size, __builtin_extract_return_addr(__builtin_return_address(0)));

    if (pvBlkPtr != NULL)
    {
        memset(pvBlkPtr, 0x0f, size);
    }

    return pvBlkPtr;
}

extern void
free(
    void * ptr)
{
    __vd_free(ptr);
}

extern void *
calloc(
    size_t nmemb,
    size_t size)
{
    return __vd_alloc(nmemb * size, __builtin_extract_return_addr(__builtin_return_address(0)));
}

extern void *
realloc(
    void * ptr,
    size_t size)
{
    void   * pvBlkPtr;
    size_t stBlkSize;

#ifdef _VD_DBG_MMAP

    if (ptr != NULL)
    {
        pvBlkPtr = (char *) ptr - sizeof(vd_mem_blk);

        if (((vd_mem_blk *) pvBlkPtr)->uiMask1 != 0x5a5a5a5a ||
            ((vd_mem_blk *) pvBlkPtr)->uiMask2 != 0xa5a5a5a5)
        {
            abort();
        }

        if ((stBlkSize = (((vd_mem_blk *) pvBlkPtr)->uiLeng1 ^ 0x5a5a5a5a)) !=
                         (((vd_mem_blk *) pvBlkPtr)->uiLeng2 ^ 0xa5a5a5a5))
        {
            abort();
        }
    }

#else  /* _VD_DBG_MMAP */

    stBlkSize = malloc_usable_size(ptr);

#endif /* _VD_DBG_MMAP */

    pvBlkPtr = __vd_alloc(size, __builtin_extract_return_addr(__builtin_return_address(0)));

    if (pvBlkPtr != NULL)
    {
        memset(pvBlkPtr, 0x0f, size);
    }

    if (ptr != NULL && pvBlkPtr != NULL)
    {
        memcpy(pvBlkPtr, ptr, (stBlkSize < size ? stBlkSize : size)),
            __vd_free(ptr);
    }

    return pvBlkPtr;
}

#endif /* _VD_DEBUG */

#endif /* _WIN32 */

