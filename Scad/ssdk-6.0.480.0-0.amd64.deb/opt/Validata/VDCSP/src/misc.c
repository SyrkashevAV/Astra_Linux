/*
 * Copyright (C) �� ����� 1997-1999
 * Copyright (C) �������� 1999-2018
 * ��� 䠩� ᮤ�ন� ���ଠ��,
 * ������� ᮡ�⢥������� �������� ��������.
 *
 * �� ���� �⮣� 䠩�� �� ����� ���� ᪮��஢���,
 * ��ࠢ����, ��ॢ����� �� ��㣨� �모,
 * ������������ ��� ������஢��� ��� ᯮᮡ��,
 * �⪮�����஢���, ��।��� �� �� � ��� ��
 * ���� ���������� ��⥬� ��� �।���⥫쭮��
 * �����祭�� ᮣ��襭�� � ��������� ��������.
 */

/******************************************************************************/

#include "util.h"

/******************************************************************************/

int                  print_help = 0;

string_t             profile   = (string_t) CRYPT_MY;
int                  registry  = 0;
int                  minimal   = 0;

int                  ophash    = 0;
int                  opsign    = 0;
int                  opvrfy    = 0;
int                  opencr    = 0;
int                  opdecr    = 0;
int                  msginf    = 0;
int                  optssg    = 0;
int                  optsvr    = 0;
int                  opocin    = 0;
int                  optool    = 0;

int                  opatta    = 0;
int                  opdeta    = 0;
int                  openob    = 0;
int                  opfncr    = 0;
int                  opsped    = 0;
int                  openpr    = 0;
int                  opcrpr    = 0;
int                  opcrst    = 0;
int                  opimob    = 0;
int                  opexrq    = 0;

int                  ldap      = 0;
int                  aiacdp    = 0;
int                  sendcert  = 0;
string_t             algorithm = NULL;
int                  format    = 0;
const char           * logfile = NULL;
FILE                 * flog    = NULL;

const char           * finp    = NULL;
const char           * fout    = NULL;
const char           * fdat    = NULL;

int                  num_recipients      = 0;
certificate_t        recipients[MAX_NUM] = { { 0 } };

int                  num_extkeyus        = 0;
const char           * extkeyus[MAX_NUM] = { 0 };
int                  num_policies        = 0;
const char           * policies[MAX_NUM] = { 0 };

const char           * url     = NULL;

certinfo_t           fields    = 0;
int                  stream    = 0;
int                  detached  = 0;
int                  crlupdate = 0;
int                  critical  = 0;

string_t             query     = NULL;

int                  iterat    = 100;
int                  threads   = 1;

const char           * uripse  = NULL;
const char           * uriloc  = NULL;
const char           * urildp  = NULL;

flag_t               flag      = 0;

certid_t             certid    = { 0 };
mem_blk_t            passwd    = { 0 };

mem_blk_t            hash_r    = { 0 };

sign_param_t         sign_p    = { 0 };

verify_param_t       verify_p  = { 0 };
verify_result_t      verify_r  = { 0 };

verify_policy_param_t
                     policy_p  = { 0 };

encrypt_param_t      encrypt_p = { 0 };

decrypt_param_t      decrypt_p = { 0 };
decrypt_result_t     decrypt_r = { { 0 } };

cms_msginf_t         msginf_r  = { 0 };

tsp_request_param_t  tssign_p  = { 0 };

tsp_verify_param_t   tsverif_p = { 0 };
tsp_verify_result_t  tsverif_r = { 0 };

ocsp_request_param_t ocspsig_p = { 0 };

ocsp_verify_param_t  ocspver_p = { 0 };
ocsp_verify_result_t ocspver_r = { -1, 0 };

extension_t          extn_p    = { 0 };
find_param_t         find_p    = { 0 };
find_result_t        find_r    = { 0 };

import_param_t       import_p  = { 0 };
export_param_t       export_p  = { 0 };

context_t            hCtx[2]   = { 0 };

/******************************************************************************/

char *
oem_to_char(
    const char * string)
{
#if defined(_WIN32) || !defined(RUSSIAN)
    char * buffer = strdup(string);
    if (buffer)
        string = buffer;
#endif /* _WIN32 || !RUSSIAN */
#if !defined(_WIN32) && defined(RUSSIAN)
    iconv_t conv;
    char    * buffer = NULL;

    conv = iconv_open("CP1251", "UTF-8");
    if (conv != (iconv_t) -1)
    {
        char * inptr = (char *) string, * outptr = NULL;
        size_t inlen = strlen(inptr) + 1, outlen = inlen;

        buffer = outptr = malloc(outlen);
        if (buffer)
        {
            if (iconv(conv, &inptr, &inlen, &outptr, &outlen) != (size_t) -1)
                string = buffer;
            else
                free(buffer);
        }
        iconv_close(conv);
    }
#endif /* !_WIN32 && RUSSIAN */
    return (char *) string;
}

/******************************************************************************/

char *
char_to_oem(
    const char * string)
{
#if defined(_WIN32) || !defined(RUSSIAN)
    char * buffer = strdup(string);
    if (buffer)
    {
#ifdef _WIN32
        CharToOem(buffer, buffer);
#endif /* _WIN32 */
        string = buffer;
    }
#endif /* _WIN32 || !RUSSIAN */
#if !defined(_WIN32) && defined(RUSSIAN)
    iconv_t conv;
    char    * buffer = NULL;

    conv = iconv_open("UTF-8", "CP1251");
    if (conv != (iconv_t) -1)
    {
        char * inptr = (char *) string, * outptr = NULL;
        size_t inlen = strlen(inptr) + 1, outlen = 4 * inlen;

        buffer = outptr = malloc(outlen);
        if (buffer)
        {
            if (iconv(conv, &inptr, &inlen, &outptr, &outlen) != (size_t) -1)
                string = buffer;
            else
                free(buffer);
        }
        iconv_close(conv);
    }
#endif /* !_WIN32 && RUSSIAN */
    return (char *) string;
}

/******************************************************************************/

int
file_print(
    FILE * stream,
    const char * format,
    ...)
{
    va_list args;
    int     ret;
#if !defined(_WIN32) && defined(RUSSIAN)
    iconv_t conv;
    char    * buffer = NULL;

    conv = iconv_open("UTF-8", "CP866");
    if (conv != (iconv_t) -1)
    {
        char * inptr = (char *) format, * outptr = NULL;
        size_t inlen = strlen(inptr) + 1, outlen = 4 * inlen;

        buffer = outptr = malloc(outlen);
        if (buffer)
        {
            if (iconv(conv, &inptr, &inlen, &outptr, &outlen) != (size_t) -1)
                format = buffer;
        }
        iconv_close(conv);
    }
#endif /* !_WIN32 && RUSSIAN */
    va_start(args, format);
    ret = vfprintf(stream, format, args);
    va_end(args);
#if !defined(_WIN32) && defined(RUSSIAN)
    if (buffer)
        free(buffer);
#endif /* !_WIN32 && RUSSIAN */
    return ret;
}

/******************************************************************************/

char *
hex2string(
    unsigned char * buffer,
    int len)
{
    char          * tmp, * q;
    unsigned char * p;
    int           i;
    static char   hexdig[] = "0123456789ABCDEF";
    if (!buffer || !len)
        return NULL;
    if (!(tmp = malloc(len * 3 + 1)))
        return NULL;
    q = tmp;
    for (i = 0, p = buffer; i < len; i ++, p ++)
    {
        *q ++ = hexdig[(*p >> 4) & 0xf];
        *q ++ = hexdig[*p & 0xf];
        *q ++ = ':';
    }
    q[-1] = 0;
    return tmp;
}

/******************************************************************************/

unsigned char *
string2hex(
    char * str,
    int * len)
{
    unsigned char * hexbuf, * q;
    unsigned char ch, cl, * p;
    if (!str)
        return NULL;
    if (!(hexbuf = malloc(strlen(str) >> 1)))
        goto err;
    for (p = (unsigned char *) str, q = hexbuf; *p; )
    {
        ch = *p ++;
        if (ch == ':')
            continue;
        cl = *p ++;
        if (!cl)
        {
            free(hexbuf);
            return NULL;
        }
        if (isupper(ch))
            ch = (unsigned char) tolower(ch);
        if (isupper(cl))
            cl = (unsigned char) tolower(cl);

        if ((ch >= '0') && (ch <= '9'))
            ch -= '0';
        else if ((ch >= 'a') && (ch <= 'f'))
            ch -= 'a' - 10;
        else
            goto err;

        if ((cl >= '0') && (cl <= '9'))
            cl -= '0';
        else if ((cl >= 'a') && (cl <= 'f'))
            cl -= 'a' - 10;
        else
            goto err;

        *q ++ = (ch << 4) | cl;
    }

    if (len)
        *len = q - hexbuf;
    return hexbuf;

 err:
    if (hexbuf)
        free(hexbuf);
    return NULL;
}

/******************************************************************************/

#ifdef _WIN32

int
load_recipients(
    const char * fileName,
    certificate_t * arrRecips,
    int * numRecips)
{
    char str[4096] = { 0 };
    int  i, res, num;

    if (access(fileName, 4 /* R_OK */) < 0)
    {
#ifdef RUSSIAN
        file_print(stdout, "�訡�� ����㯠 � 䠩�� %s\n", fileName);
#else
        file_print(stdout, "File %s access error\n", fileName);
#endif
        return 0;
    }

    res = GetPrivateProfileString("General", "Number", NULL, str, sizeof(str), fileName);
    if (res < 1)
    {
#ifdef RUSSIAN
        file_print(stdout, "�訡�� �⥭�� ������⢠ �����⥫�� (Number) �� ᥪ樨 ����஥� (General)\n");
#else
        file_print(stdout, "Error reading number of recipients (Number) from settings section (General)\n");
#endif
        return 0;
    }

    num = atoi(str);
    if (num <= 0 || num >= MAX_NUM)
    {
#ifdef RUSSIAN
        file_print(stdout, "������⢮ �����⥫�� (%d) ����� ���ᨬ��쭮 ���������� (%d)\n", num, MAX_NUM);
#else
        file_print(stdout, "Number of recipients (%d) exceeds allowed maximum (%d)\n", num, MAX_NUM);
#endif
        return 0;
    }

    for (i = 0; i < num; i ++)
    {
        char       section[256];
        certinfo_t fields;

        sprintf(section, "Recipient%d", i + 1);

        res = GetPrivateProfileString(section, "Type", NULL, str, sizeof(str), fileName);
        if (res <= 3)
        {
#ifdef RUSSIAN
            file_print(stdout, "�訡�� �⥭�� ⨯� ����� (Type) �� ᥪ樨 �����⥫� %d (%s)\n", i + 1, section);
#else
            file_print(stdout, "Error reading record type (Type) from recipient section %d (%s)\n", i + 1, section);
#endif
            return 0;
        }

        if (0 == strcasecmp(str, "KeyId"))
            fields = FIELD_KEYID;
        else if (0 == strcasecmp(str, "Subject"))
            fields = FIELD_SUBJECT;
        else if (0 == strcasecmp(str, "Hash"))
            fields = FIELD_CERTHASH;
        else if (0 == strcasecmp(str, "Mail"))
            fields = FIELD_SUBJECTALTNAME;
        else
        {
#ifdef RUSSIAN
            file_print(stdout, "��� ����� %s �� ᥪ樨 �����⥫� %d (%s) �� �����ন������\n", str, i + 1, section);
#else
            file_print(stdout, "Record type %s from recipient section %d (%s) is not supported\n", str, i + 1, section);
#endif
            return 0;
        }

        res = GetPrivateProfileString(section, "Value", NULL, str, sizeof(str), fileName);
        if (res <= 4)
        {
#ifdef RUSSIAN
            file_print(stdout, "�訡�� �⥭�� ���祭�� (Value) �� ᥪ樨 �����⥫� %d (%s)\n", i + 1, section);
#else
            file_print(stdout, "Error reading record value (Value) from recipient section %d (%s)\n", i + 1, section);
#endif
            return 0;
        }

        arrRecips[i].fields = fields;
        switch (fields)
        {
        case FIELD_KEYID:
            arrRecips[i].keyId = (string_t) strdup(str);
            if (!arrRecips[i].keyId)
                return 0;
            break;

        case FIELD_SUBJECT:
            arrRecips[i].subject = (string_t) strdup(str);
            if (!arrRecips[i].subject)
                return 0;
            break;

        case FIELD_CERTHASH:
            arrRecips[i].certHash.buf = string2hex(str, (int *) &arrRecips[i].certHash.len);
            if (!arrRecips[i].certHash.buf)
                return 0;
            break;

        case FIELD_SUBJECTALTNAME:
            arrRecips[i].subjectAltName.emailAddress = (string_t) strdup(str);
            if (!arrRecips[i].subjectAltName.emailAddress)
                return 0;
            break;
        }
    }

    *numRecips = num;

    return 1;
}

#endif /* _WIN32 */

/******************************************************************************/

void
certificate_print(
    FILE * file,
    certificate_t * cert)
{
    char * sfld;
    if (!cert)
        return;
    if ((cert->fields & FIELD_SERIAL) && (cert->serialNumber))
#ifdef RUSSIAN
        file_print(file, "��਩�� �����..............: %s\n", cert->serialNumber);
#else
        file_print(file, "Serial number...............: %s\n", cert->serialNumber);
#endif
    if ((cert->fields & FIELD_ISSUER) && (cert->issuer))
    {
        sfld = char_to_oem((const char *) cert->issuer);
#ifdef RUSSIAN
        file_print(file, "����⥫�....................: %s\n", sfld);
#else
        file_print(file, "Issuer......................: %s\n", sfld);
#endif
        if (sfld != (char *) cert->issuer)
            free(sfld);
    }
    if ((cert->fields & FIELD_SUBJECT) && (cert->subject))
    {
        sfld = char_to_oem((const char *) cert->subject);
#ifdef RUSSIAN
        file_print(file, "��������....................: %s\n", sfld);
#else
        file_print(file, "Subject.....................: %s\n", sfld);
#endif
        if (sfld != (char *) cert->subject)
            free(sfld);
    }
    if (cert->fields & FIELD_NOTBEFORE)
    {
        time_t tim = (time_t) cert->notBefore;
#ifdef RUSSIAN
        file_print(file, "����⢨⥫�� �..............: %s", ctime(&tim));
#else
        file_print(file, "Not before..................: %s", ctime(&tim));
#endif
    }
    if (cert->fields & FIELD_NOTAFTER)
    {
        time_t tim = (time_t) cert->notAfter;
#ifdef RUSSIAN
        file_print(file, "����⢨⥫�� ��.............: %s", ctime(&tim));
#else
        file_print(file, "Not after...................: %s", ctime(&tim));
#endif
    }
    if ((cert->fields & FIELD_SUBJECTALTNAME))
    {
        altname_t * a = &cert->subjectAltName;
        if (a->emailAddress)
        {
            sfld = char_to_oem((const char *) a->emailAddress);
#ifdef RUSSIAN
            file_print(file, "  ���⮢� ���� RFC822.....: %s\n", sfld);
#else
            file_print(file, "  Email address.............: %s\n", sfld);
#endif
            if (sfld != (char *) a->emailAddress)
                free(sfld);
        }
        if (a->DNS)
        {
            sfld = char_to_oem((const char *) a->DNS);
#ifdef RUSSIAN
            file_print(file, "  DNS ���...................: %s\n", sfld);
#else
            file_print(file, "  DNS.......................: %s\n", sfld);
#endif
            if (sfld != (char *) a->DNS)
                free(sfld);
        }
        if (a->URI)
        {
            sfld = char_to_oem((const char *) a->URI);
#ifdef RUSSIAN
            file_print(file, "  ��뫪� URL................: %s\n", sfld);
#else
            file_print(file, "  URL.......................: %s\n", sfld);
#endif
            if (sfld != (char *) a->URI)
                free(sfld);
        }
        if (a->IP)
#ifdef RUSSIAN
            file_print(file, "  IP ����..................: %s\n", a->IP);
#else
            file_print(file, "  IP address................: %s\n", a->IP);
#endif
        if (a->organizationName)
        {
            sfld = char_to_oem((const char *) a->organizationName);
#ifdef RUSSIAN
            file_print(file, "  �࣠������...............: %s\n", sfld);
#else
            file_print(file, "  Organization..............: %s\n", sfld);
#endif
            if (sfld != (char *) a->organizationName)
                free(sfld);
        }
        if (a->registredAddress)
        {
            sfld = char_to_oem((const char *) a->registredAddress);
#ifdef RUSSIAN
            file_print(file, "  �������� 㫨��, ����� ����: %s\n", sfld);
#else
            file_print(file, "  Street address............: %s\n", sfld);
#endif
            if (sfld != (char *) a->registredAddress)
                free(sfld);
        }
        if (a->surname)
        {
            sfld = char_to_oem((const char *) a->surname);
#ifdef RUSSIAN
            file_print(file, "  �������...................: %s\n", sfld);
#else
            file_print(file, "  Surname...................: %s\n", sfld);
#endif
            if (sfld != (char *) a->surname)
                free(sfld);
        }
        if (a->businessCategory)
        {
            sfld = char_to_oem((const char *) a->businessCategory);
#ifdef RUSSIAN
            file_print(file, "  ���������.................: %s\n", sfld);
#else
            file_print(file, "  Business category.........: %s\n", sfld);
#endif
            if (sfld != (char *) a->businessCategory)
                free(sfld);
        }
        if (a->telephoneNumber)
        {
            sfld = char_to_oem((const char *) a->telephoneNumber);
#ifdef RUSSIAN
            file_print(file, "  ����� ⥫�䮭�............: %s\n", sfld);
#else
            file_print(file, "  Phone number..............: %s\n", sfld);
#endif
            if (sfld != (char *) a->telephoneNumber)
                free(sfld);
        }
        if (a->description)
        {
            sfld = char_to_oem((const char *) a->description);
#ifdef RUSSIAN
            file_print(file, "  ���ᠭ��..................: %s\n", sfld);
#else
            file_print(file, "  Description...............: %s\n", sfld);
#endif
            if (sfld != (char *) a->description)
                free(sfld);
        }
        if (a->account_number)
        {
            sfld = char_to_oem((const char *) a->account_number);
#ifdef RUSSIAN
            file_print(file, "  ����� ���⭮�� ���....: %s\n", sfld);
#else
            file_print(file, "  Account number............: %s\n", sfld);
#endif
            if (sfld != (char *) a->account_number)
                free(sfld);
        }
        if (a->bank_id)
        {
            sfld = char_to_oem((const char *) a->bank_id);
#ifdef RUSSIAN
            file_print(file, "  ������᪨� ������. ���...: %s\n", sfld);
#else
            file_print(file, "  Bank identifier...........: %s\n", sfld);
#endif
            if (sfld != (char *) a->bank_id)
                free(sfld);
        }
        if (a->physicalDelivery)
        {
            sfld = char_to_oem((const char *) a->physicalDelivery);
#ifdef RUSSIAN
            file_print(file, "  ���⮢� ����............: %s\n", sfld);
#else
            file_print(file, "  Physical delivery.........: %s\n", sfld);
#endif
            if (sfld != (char *) a->physicalDelivery)
                free(sfld);
        }
        if (a->exchange_address)
        {
            sfld = char_to_oem((const char *) a->exchange_address);
#ifdef RUSSIAN
            file_print(file, "  ���� Exchange............: %s\n", sfld);
#else
            file_print(file, "  Exchange address..........: %s\n", sfld);
#endif
            if (sfld != (char *) a->exchange_address)
                free(sfld);
        }
#ifdef USE_NOTES
        if (a->notes_address)
        {
            sfld = char_to_oem((const char *) a->notes_address);
#ifdef RUSSIAN
            file_print(file, "  ���� Notes...............: %s\n", sfld);
#else
            file_print(file, "  Notes address.............: %s\n", sfld);
#endif
            if (sfld != (char *) a->notes_address)
                free(sfld);
        }
#endif
    }
    if ((cert->fields & FIELD_KEYID) && (cert->keyId))
#ifdef RUSSIAN
        file_print(file, "�����䨪��� ����.........: %s\n", cert->keyId);
#else
        file_print(file, "Key identifier..............: %s\n", cert->keyId);
#endif
    if ((cert->fields & FIELD_EXTENSIONS) && (cert->extension_num && cert->extensions))
    {
        int indx;
        for (indx = 0; indx < (int) cert->extension_num; indx ++)
        {
            mem_blk_t iblk = { cert->extensions[indx].len, cert->extensions[indx].data };
            mem_blk_t oblk = { 0 };
            if (!strcmp((char *) cert->extensions[indx].oid, "2.5.29.14"))
            {
                char * s = hex2string(iblk.buf, iblk.len);
#ifdef RUSSIAN
                file_print(file, "������. ���� ��������....: %s\n", s);
#else
                file_print(file, "Subject key identifier......: %s\n", s);
#endif
                free(s);
            }
            if (!strcmp((char *) cert->extensions[indx].oid, "2.5.29.35"))
                if (!VCERT_ParseKeyIdentifierEx(hCtx[0], &iblk, &oblk))
                {
                    char * s = hex2string(oblk.buf, oblk.len);
#ifdef RUSSIAN
                    file_print(file, "������. ���� ����⥫�.....: %s\n", s);
#else
                    file_print(file, "Authority key identifier....: %s\n", s);
#endif
                    free(s);
                }
            if (!strcmp((char *) cert->extensions[indx].oid, "1.2.643.100.114"))
                if (cert->extensions[indx].data && cert->extensions[indx].len > 0)
                {
#ifdef RUSSIAN
                    file_print(file, "��� �����䨪�樨 �� �뤠�: %d\n",
                               (int) cert->extensions[indx].data[cert->extensions[indx].len - 1]);
#else
                    file_print(file, "Identification kind.........: %d\n",
                               (int) cert->extensions[indx].data[cert->extensions[indx].len - 1]);
#endif
                }
            if (oblk.buf)
                VCERT_FreeMem(hCtx[0], oblk.buf);
        }
    }
    if ((cert->fields & FIELD_CERTHASH) && (cert->certHash.len && cert->certHash.buf))
    {
        char * s = hex2string(cert->certHash.buf, cert->certHash.len);
#ifdef RUSSIAN
        file_print(file, "��� ����⥫�/�਩�. �����.: %s\n", s);
#else
        file_print(file, "Issuer/Serial number hash...: %s\n", s);
#endif
        free(s);
    }
    if ((cert->fields & FIELD_ALGORITHM) && (cert->algorithm))
#ifdef RUSSIAN
        file_print(file, "������ ���� �஢�ન ��..: %s\n", cert->algorithm);
#else
        file_print(file, "Public key algorithm........: %s\n", cert->algorithm);
#endif
}

/******************************************************************************/

void
crl_print(
    FILE * file,
    crl_t * crl)
{
    char * sfld;
    if (!crl)
        return;
    if ((crl->fields & FIELD_CRL_ISSUER) && (crl->issuer))
    {
        sfld = char_to_oem((const char *) crl->issuer);
#ifdef RUSSIAN
        file_print(file, "����⥫�....................: %s\n", sfld);
#else
        file_print(file, "Issuer......................: %s\n", sfld);
#endif
        if (sfld != (char *) crl->issuer)
            free(sfld);
    }
    if (crl->fields & FIELD_CRL_LASTUPDATE)
    {
        time_t tim = (time_t) crl->lastUpdate;
#ifdef RUSSIAN
        file_print(file, "��� ���᪠................: %s", ctime(&tim));
#else
        file_print(file, "Last update.................: %s", ctime(&tim));
#endif
    }
    if (crl->fields & FIELD_CRL_NEXTUPDATE)
    {
        time_t tim = (time_t) crl->nextUpdate;
#ifdef RUSSIAN
        file_print(file, "������騩 ����............: %s", ctime(&tim));
#else
        file_print(file, "Next update.................: %s", ctime(&tim));
#endif
    }
    if (crl->fields & FIELD_CRL_NUMBER)
    {
#ifdef RUSSIAN
        file_print(file, "���浪��� ����� ���........: %d\n", crl->number);
#else
        file_print(file, "CRL number..................: %d\n", crl->number);
#endif
    }
    if (crl->fields & FIELD_CRL_REVOKED)
    {
#ifdef RUSSIAN
        file_print(file, "�����. ���㫨஢��. ����..: %d\n", crl->revcert_num);
#else
        file_print(file, "Number of revocations.......: %d\n", crl->revcert_num);
#endif
    }
    if ((crl->fields & FIELD_CRL_CRLHASH) && (crl->crlHash.len && crl->crlHash.buf))
    {
        char * s = hex2string(crl->crlHash.buf, crl->crlHash.len);
#ifdef RUSSIAN
        file_print(file, "���/������. ���� ����⥫�.: %s\n", s);
#else
        file_print(file, "Issuer hash/key identifier..: %s\n", s);
#endif
        free(s);
    }
}

/******************************************************************************/

void
msginf_print(
    FILE * file,
    cms_msginf_t * info)
{
    char * sfld;
    int idx1, idx2;
    switch (info->type)
    {
    case FLAG_CMS_MSGINF_TYPE_SIGN:
#ifdef RUSSIAN
        if (info->flags & FLAG_CMS_MSGINF_FLAG_NDEF)
        {
            if (info->flags & FLAG_CMS_MSGINF_FLAG_DTCH)
                file_print(file, "\n�����ᠭ��� CMS ᮮ�饭�� [ ��⮪��� �ଠ� ; ��ᮥ������� �� ]\n");
            else
                file_print(file, "\n�����ᠭ��� CMS ᮮ�饭�� [ ��⮪��� �ଠ� ; ��ᮥ������� �� ]\n");
        }
        else
            if (info->flags & FLAG_CMS_MSGINF_FLAG_DTCH)
                file_print(file, "\n�����ᠭ��� CMS ᮮ�饭�� [ ����� �ଠ� ; ��ᮥ������� �� ]\n");
            else
                file_print(file, "\n�����ᠭ��� CMS ᮮ�饭�� [ ����� �ଠ� ; ��ᮥ������� �� ]\n");
#else
        file_print(file, "\nSigned CMS message [ %s ; %s ]\n",
                         (info->flags & FLAG_CMS_MSGINF_FLAG_NDEF) ? "Stream"   : "Block"   ,
                         (info->flags & FLAG_CMS_MSGINF_FLAG_DTCH) ? "Detached" : "Attached");
#endif
        for (idx1 = 0; idx1 < (int) info->signer_num; idx1 ++)
        {
#ifdef RUSSIAN
            file_print(file, "\n�����ᠭ� [% 3d]\n", idx1 + 1);
#else
            file_print(file, "\nSigner [% 3d]\n", idx1 + 1);
#endif
            if (info->signers[idx1].digestAlg)
#ifdef RUSSIAN
                file_print(file, "������ ���-�㭪樨........: %s\n", info->signers[idx1].digestAlg);
#else
                file_print(file, "Digest algorithm............: %s\n", info->signers[idx1].digestAlg);
#endif
            if (info->signers[idx1].signatureAlg)
#ifdef RUSSIAN
                file_print(file, "������ ��.................: %s\n", info->signers[idx1].signatureAlg);
#else
                file_print(file, "Signature algorithm.........: %s\n", info->signers[idx1].signatureAlg);
#endif
            switch (info->signers[idx1].signerId.type)
            {
            case FLAG_CMS_CERTID_TYPE_ISSN:
                if (info->signers[idx1].signerId.issuer)
                {
                    sfld = char_to_oem((const char *) info->signers[idx1].signerId.issuer);
#ifdef RUSSIAN
                    file_print(file, "��� ����⥫� �����ᠭ�.....: %s\n", sfld);
#else
                    file_print(file, "Signer issuer name..........: %s\n", sfld);
#endif
                    if (sfld != (char *) info->signers[idx1].signerId.issuer)
                        free(sfld);
                }
                if (info->signers[idx1].signerId.serialNum)
#ifdef RUSSIAN
                    file_print(file, "��਩�� ����� �����ᠭ�...: %s\n", info->signers[idx1].signerId.serialNum);
#else
                    file_print(file, "Signer serial number........: %s\n", info->signers[idx1].signerId.serialNum);
#endif
                if (info->signers[idx1].signerId.certHash)
#ifdef RUSSIAN
                    file_print(file, "��� ����⥫�/�਩�. �����.: %s\n", info->signers[idx1].signerId.certHash);
#else
                    file_print(file, "Issuer/serial number hash...: %s\n", info->signers[idx1].signerId.certHash);
#endif
                break;
            case FLAG_CMS_CERTID_TYPE_SKID:
                if (info->signers[idx1].signerId.subjKeyId)
#ifdef RUSSIAN
                    file_print(file, "������. ���� �����ᠭ�...: %s\n", info->signers[idx1].signerId.subjKeyId);
#else
                    file_print(file, "Signer key identifier.......: %s\n", info->signers[idx1].signerId.subjKeyId);
#endif
                break;
            }
            if (info->signers[idx1].signingTime)
            {
                time_t tim = (time_t) info->signers[idx1].signingTime;
#ifdef RUSSIAN
                file_print(file, "�६� ��⠭���� ��..........: %s", ctime(&tim));
#else
                file_print(file, "Signing time................: %s", ctime(&tim));
#endif
            }
            for (idx2 = 0; idx2 < (int) info->signers[idx1].authAttr_num; idx2 ++)
                if (info->signers[idx1].authAttrs[idx2])
#ifdef RUSSIAN
                    file_print(file, "�����ᠭ�� ��ਡ�� [% 3d]...: %s\n", idx2 + 1, info->signers[idx1].authAttrs[idx2]);
#else
                    file_print(file, "Authenticat. attribute [% 3d]: %s\n", idx2 + 1, info->signers[idx1].authAttrs[idx2]);
#endif
            for (idx2 = 0; idx2 < (int) info->signers[idx1].unauthAttr_num; idx2 ++)
                if (info->signers[idx1].unauthAttrs[idx2])
#ifdef RUSSIAN
                    file_print(file, "�������ᠭ�� ��ਡ�� [% 3d].: %s\n", idx2 + 1, info->signers[idx1].unauthAttrs[idx2]);
#else
                    file_print(file, "Non-authent. attribute [% 3d]: %s\n", idx2 + 1, info->signers[idx1].unauthAttrs[idx2]);
#endif
        }
        break;

    case FLAG_CMS_MSGINF_TYPE_ENVL:
#ifdef RUSSIAN
        if (info->flags & FLAG_CMS_MSGINF_FLAG_NDEF)
            file_print(file, "\n����஢����� CMS ᮮ�饭�� [ ��⮪��� �ଠ� ]\n");
        else
            file_print(file, "\n����஢����� CMS ᮮ�饭�� [ ����� �ଠ� ]\n");
#else
        file_print(file, "\nEncrypted CMS message [ %s ]\n",
                         (info->flags & FLAG_CMS_MSGINF_FLAG_NDEF) ? "Stream" : "Block");
#endif
        for (idx1 = 0; idx1 < (int) info->recipient_num; idx1 ++)
        {
#ifdef RUSSIAN
            file_print(file, "\n�����⥫� [% 3d]\n", idx1 + 1);
#else
            file_print(file, "\nRecipient [% 3d]\n", idx1 + 1);
#endif
            switch (info->recipients[idx1].originatorId.type)
            {
            case FLAG_CMS_CERTID_TYPE_ISSN:
                if (info->recipients[idx1].originatorId.issuer)
                {
                    sfld = char_to_oem((const char *) info->recipients[idx1].originatorId.issuer);
#ifdef RUSSIAN
                    file_print(file, "��� ����⥫� ��ࠢ�⥫�....: %s\n", sfld);
#else
                    file_print(file, "Sender issuer name..........: %s\n", sfld);
#endif
                    if (sfld != (char *) info->recipients[idx1].originatorId.issuer)
                        free(sfld);
                }
                if (info->recipients[idx1].originatorId.serialNum)
#ifdef RUSSIAN
                    file_print(file, "��਩�� ����� ��ࠢ�⥫�..: %s\n", info->recipients[idx1].originatorId.serialNum);
#else
                    file_print(file, "Sender serial number........: %s\n", info->recipients[idx1].originatorId.serialNum);
#endif
                if (info->recipients[idx1].originatorId.certHash)
#ifdef RUSSIAN
                    file_print(file, "��� ����⥫�/�਩�. �����.: %s\n", info->recipients[idx1].originatorId.certHash);
#else
                    file_print(file, "Issuer/serial number hash...: %s\n", info->recipients[idx1].originatorId.certHash);
#endif
                break;
            case FLAG_CMS_CERTID_TYPE_SKID:
                if (info->recipients[idx1].originatorId.subjKeyId)
#ifdef RUSSIAN
                    file_print(file, "������. ���� ��ࠢ�⥫�..: %s\n", info->recipients[idx1].originatorId.subjKeyId);
#else
                    file_print(file, "Sender key identifier.......: %s\n", info->recipients[idx1].originatorId.subjKeyId);
#endif
                break;
            }
            if (info->recipients[idx1].publicKeyAlg)
#ifdef RUSSIAN
                file_print(file, "������ ���� �஢�ન ��..: %s\n", info->recipients[idx1].publicKeyAlg);
#else
                file_print(file, "Public key algorithm........: %s\n", info->recipients[idx1].publicKeyAlg);
#endif
            if (info->recipients[idx1].cipherAlg)
#ifdef RUSSIAN
                file_print(file, "������ ᮣ��ᮢ���� ����.: %s\n", info->recipients[idx1].cipherAlg);
#else
                file_print(file, "Key agreement algorithm.....: %s\n", info->recipients[idx1].cipherAlg);
#endif
            switch (info->recipients[idx1].recipientId.type)
            {
            case FLAG_CMS_CERTID_TYPE_ISSN:
                if (info->recipients[idx1].recipientId.issuer)
                {
                    sfld = char_to_oem((const char *) info->recipients[idx1].recipientId.issuer);
#ifdef RUSSIAN
                    file_print(file, "��� ����⥫� �����⥫�.....: %s\n", sfld);
#else
                    file_print(file, "Recipient issuer name.......: %s\n", sfld);
#endif
                    if (sfld != (char *) info->recipients[idx1].recipientId.issuer)
                        free(sfld);
                }
                if (info->recipients[idx1].recipientId.serialNum)
#ifdef RUSSIAN
                    file_print(file, "��਩�� ����� �����⥫�...: %s\n", info->recipients[idx1].recipientId.serialNum);
#else
                    file_print(file, "Recipient serial number.....: %s\n", info->recipients[idx1].recipientId.serialNum);
#endif
                if (info->recipients[idx1].recipientId.certHash)
#ifdef RUSSIAN
                    file_print(file, "��� ����⥫�/�਩�. �����.: %s\n", info->recipients[idx1].recipientId.certHash);
#else
                    file_print(file, "Issuer/serial number hash...: %s\n", info->recipients[idx1].recipientId.certHash);
#endif
                break;
            case FLAG_CMS_CERTID_TYPE_SKID:
                if (info->recipients[idx1].recipientId.subjKeyId)
#ifdef RUSSIAN
                    file_print(file, "������. ���� �����⥫�...: %s\n", info->recipients[idx1].recipientId.subjKeyId);
#else
                    file_print(file, "Recipient key identifier....: %s\n", info->recipients[idx1].recipientId.subjKeyId);
#endif
                break;
            }
        }
        if (info->cipherAlg)
#ifdef RUSSIAN
            file_print(file, "\n������ ��஢���� ������..: %s\n", info->cipherAlg);
#else
            file_print(file, "\nData encryption algorithm...: %s\n", info->cipherAlg);
#endif
        for (idx1 = 0; idx1 < (int) info->unprotAttr_num; idx1 ++)
            if (info->unprotAttrs[idx1])
#ifdef RUSSIAN
                file_print(file, "%s�����饭�� ��ਡ�� [% 3d]..: %s\n", !idx1 ? "\n" : "", idx1 + 1, info->unprotAttrs[idx1]);
#else
                file_print(file, "%sUnprotected attribute [% 3d].: %s\n", !idx1 ? "\n" : "", idx1 + 1, info->unprotAttrs[idx1]);
#endif
        break;
    }
}

/******************************************************************************/

void
status_print(
    FILE * file,
    error_status_t rc,
    int cnt)
{
    char tmpbuf[2048] = { 0 };
    char * tmpstr     = NULL;
    int  idx;

    VCERT_GetErrorText(rc, tmpbuf, sizeof(tmpbuf));
    tmpstr = char_to_oem((const char *) tmpbuf);
#ifdef RUSSIAN
    if (cnt >= 0)
        file_print(flog, "[% 3d] �������: %s (%08X)\n", cnt, tmpstr, (unsigned int) rc);
    else
        file_print(flog, "�������: %s (%08X)\n", tmpstr, (unsigned int) rc);
#else
    if (cnt >= 0)
        file_print(flog, "[% 3d] Result: %s (%08X)\n", cnt, tmpstr, (unsigned int) rc);
    else
        file_print(flog, "Result: %s (%08X)\n", tmpstr, (unsigned int) rc);
#endif
    if (tmpstr != tmpbuf)
        free(tmpstr);

    if (rc)
    {
        mem_blk_t erro = { 0 };
        mem_blk_t file = { 0 };
        mem_blk_t data = { 0 };
        uint32_t  line = 0;

        for (idx = 0; VCERT_GetErrorLineEx(hCtx[0], &erro, &file, &line, &data) == 0; idx ++)
        {
            char * serr = char_to_oem((const char *) erro.buf);
            char * sdat = char_to_oem((const char *) data.buf);
            char * sfil = char_to_oem((const char *) file.buf);

            if (!idx)
#ifdef RUSSIAN
                file_print(flog, "\n����७��� �⥪ �訡��:\n");
#else
                file_print(flog, "\nInternal error stack:\n");
#endif

            file_print(flog, "[%d] %s%s%s [%s:%d]\n",
                       idx, serr, (sdat[0] != '\0' ? " - " : ""), sdat, sfil, line);

            if (serr != (char *) erro.buf)
                free(serr);
            if (sdat != (char *) data.buf)
                free(sdat);
            if (sfil != (char *) file.buf)
                free(sfil);

            VCERT_FreeMem(hCtx[0], erro.buf);
            erro.buf = NULL, erro.len = 0;
            VCERT_FreeMem(hCtx[0], file.buf);
            file.buf = NULL, file.len = 0;
            VCERT_FreeMem(hCtx[0], data.buf);
            data.buf = NULL, data.len = 0;
        }
    }
}

/******************************************************************************/

int
file_mmap(
    const char * fname,
    void ** ptr,
    int * len)
{
    int ret = 0;

#ifdef _WIN32

    HANDLE hfil = INVALID_HANDLE_VALUE;
    HANDLE hmap = NULL;

    hfil = CreateFileA(fname, GENERIC_READ, FILE_SHARE_READ, NULL,
                       OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL | FILE_FLAG_SEQUENTIAL_SCAN, NULL);
    if (hfil == INVALID_HANDLE_VALUE)
    {
        ret = GetLastError();
        goto err;
    }

    *len = GetFileSize(hfil, NULL);
    if (*len == INVALID_FILE_SIZE)
    {
        ret = GetLastError();
        goto err;
    }

    hmap = CreateFileMapping(hfil, NULL, PAGE_READONLY, 0, *len, NULL);
    if (!hmap)
    {
        ret = GetLastError();
        goto err;
    }

    *ptr = (void *) MapViewOfFile(hmap, FILE_MAP_READ, 0, 0, 0);
    if (!*ptr)
    {
        ret = GetLastError();
        goto err;
    }

 err:
    if (hfil != INVALID_HANDLE_VALUE)
        CloseHandle(hfil);

    if (hmap)
        CloseHandle(hmap);

#else  /* _WIN32 */

    int         hfil = -1;
    struct stat fsiz = { 0 };

    hfil = open(fname, O_RDONLY);
    if (hfil < 0)
    {
        ret = errno;
        goto err;
    }

    if (fstat(hfil, &fsiz) < 0)
    {
        ret = errno;
        goto err;
    }

    *len = (int) fsiz.st_size;

    *ptr = mmap(NULL, (size_t) *len, PROT_READ, MAP_PRIVATE, hfil, (off_t) 0);
    if (*ptr == MAP_FAILED)
    {
        ret = errno;
        goto err;
    }

 err:
    if (hfil >= 0)
        close(hfil);

#endif /* _WIN32 */

    return ret;
}
