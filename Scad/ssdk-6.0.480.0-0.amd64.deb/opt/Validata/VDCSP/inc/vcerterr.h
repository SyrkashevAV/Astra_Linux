/*
 * Copyright (C) �� ����� 1997-1999
 * Copyright (C) �������� 1999-2018
 * ���� ���� �������� ����������,
 * ���������� �������������� �������� ��������.
 *
 * ����� ����� ����� ����� �� ����� ���� �����������,
 * ����������, ���������� �� ������ �����,
 * ������������ ��� �������������� ����� ��������,
 * ���������������, �������� �� ���� � ��� ��
 * ����� ������������ ������� ��� ����������������
 * ���������� ���������� � ��������� ��������.
 */

#ifndef _VCERTERR_H_
#define _VCERTERR_H_

#ifndef SUCCEEDED

/*
 * Generic test for success on any status value (non-negative numbers
 * indicate success)
 */

#ifdef _WIN32
#define SUCCEEDED(Status)    ((long) (Status) >= 0)
#else
#define SUCCEEDED(Status)    ((int) (Status) >= 0)
#endif

/*
 * and the inverse
 */

#ifdef _WIN32
#define FAILED(Status)    ((long) (Status) < 0)
#else
#define FAILED(Status)    ((int) (Status) < 0)
#endif

/*
 * Generic test for error on any status value
 */

#ifdef _WIN32
#define IS_ERROR(Status)    (((unsigned long) (Status) >> 31) == 1)
#else
#define IS_ERROR(Status)    (((unsigned int) (Status) >> 31) == 1)
#endif

#endif /* SUCCEEDED */

/*
 * Return the code
 */

#ifdef _WIN32
#define VCERT_CODE(Status)    ((unsigned long) ((Status) & 0xFFFF))
#else
#define VCERT_CODE(Status)    ((unsigned int) ((Status) & 0xFFFF))
#endif

/*
 *  Return the facility
 */

#ifdef _WIN32
#define VCERT_FACILITY(Status)    ((unsigned long) (((Status) >> 16) & 0x1FFF))
#else
#define VCERT_FACILITY(Status)    ((unsigned int) (((Status) >> 16) & 0x1FFF))
#endif

/*
 *  Return the severity
 */

#ifdef _WIN32
#define VCERT_SEVERITY(Status)    ((unsigned long) (((Status) >> 31) & 0x1))
#else
#define VCERT_SEVERITY(Status)    ((unsigned int) (((Status) >> 31) & 0x1))
#endif

/*
 * Create a VCERT status value from component pieces
 */

#ifdef _WIN32
#define MAKE_VCERT_STATUS(Severity, Facility, Code)        \
    ((unsigned long) (((unsigned long) (Severity) << 31) | \
                      ((unsigned long) (1       ) << 29) | \
                      ((unsigned long) (Facility) << 16) | \
                      ((unsigned long) (Code    )      )))
#else
#define MAKE_VCERT_STATUS(Severity, Facility, Code)      \
    ((unsigned int) (((unsigned int) (Severity) << 31) | \
                     ((unsigned int) (1       ) << 29) | \
                     ((unsigned int) (Facility) << 16) | \
                     ((unsigned int) (Code    )      )))
#endif

/*
 * Map a WIN32 error value into a VCERT status
 * Note: This assumes that WIN32 errors fall in the range -32k to 32k
 */

#ifdef _WIN32
#define VCERT_STATUS_FROM_WIN32(Status)                             \
    (0 != Status ? ((unsigned long) (((Status) & 0x0000FFFF     ) | \
                                     (VCERT_FACILITY_WIN32 << 16) | \
                                     (0x80000000                ))) \
                 : (                                             0))
#else
#define VCERT_STATUS_FROM_WIN32(Status)                            \
    (0 != Status ? ((unsigned int) (((Status) & 0x0000FFFF     ) | \
                                    (VCERT_FACILITY_WIN32 << 16) | \
                                    (0x80000000                ))) \
                 : (                                            0))
#endif

/*
 * Map an NT status value into a VCERT status
 */

#define VCERT_FACILITY_NT_BIT           0x10000000

#ifdef _WIN32
#define VCERT_STATUS_FROM_NT(Status)    ((unsigned long) ((Status) | FACILITY_NT_BIT))
#else
#define VCERT_STATUS_FROM_NT(Status)    ((unsigned int) ((Status) | FACILITY_NT_BIT))
#endif

/*
 * Map an OpenSSL error value into a VCERT status
 */

#define VCERT_FACILITY_OPENSSL_BIT          0x28000000

#ifdef _WIN32
#define VCERT_STATUS_FROM_OPENSSL(Status)   ((unsigned long) ((Status) | FACILITY_OPENSSL_BIT))
#else
#define VCERT_STATUS_FROM_OPENSSL(Status)   ((unsigned int) ((Status) | FACILITY_OPENSSL_BIT))
#endif

/*
 * Operation completed successefully
 */

#define VCERT_OK                               0

#define VCERT_FACILITY_WIN32                   0x7
#define VCERT_FACILITY_USER                    0x60
#define VCERT_FACILITY_SYSTEM                  0x0
#define VCERT_FACILITY_SERVICE                 0x40
#define VCERT_FACILITY_SECURITY                0x20
#define VCERT_FACILITY_OPENSSL                 0x80
#define VCERT_FACILITY_LOGGING                 0x30
#define VCERT_FACILITY_KERNEL                  0x10
#define VCERT_FACILITY_CRYPT                   0x70
#define VCERT_FACILITY_CONFIG                  0x71
#define VCERT_FACILITY_ADMIN                   0x72

/*
 * WIN32 Service codes
 */
#define SVC_I_EVENT_LOG                        0x20400001L
#define SVC_I_STARTED                          0x20400002L
#define SVC_I_STOPPED                          0x20400003L
#define SVC_I_STOPPING                         0x20400004L
#define SVC_E_OPENSCM                          0xE0400005L
#define SVC_E_CREATESERVICE                    0xE0400006L
#define SVC_E_OPENSERVICE                      0xE0400007L
#define SVC_W_DELETESERVICE                    0xE0400008L
#define SVC_E_REGISTERSRVHANDLER               0xE0400009L
#define SVC_W_BADSRVREQUEST                    0xE040000AL
#define SVC_I_STARTING                         0x2040000BL
#define SVC_I_PAUSED                           0x2040000CL

/*
 * Logging codes
 */
#define LOG_I_ADMINCONNECT                     0x20300001L
#define LOG_I_CRSRVCONNECT                     0x20300002L

/*
 * Crypto codes
 */
#define VCERT_E_GENERIC                        0xE0700001L
#define VCERT_E_INVALID_PARAMETER              0xE0700002L
#define VCERT_E_INVALID_CONTEXT                0xE0700003L
#define VCERT_E_OPERATION_NOT_SUPPORTED        0xE0700004L
#define VCERT_E_INVALID_FLAG                   0xE0700005L
#define VCERT_E_NO_MEMORY                      0xE0700006L
#define VCERT_E_DIGEST                         0xE0700007L
#define VCERT_E_CERT_USAGE                     0xE0700008L
#define VCERT_E_CERT_FIND_PRIVATE_KEY          0xE0700009L
#define VCERT_E_CMS_ADD_SIGNATURE              0xE070000CL
#define VCERT_E_CMS_ASN1_DECODE                0xE070000FL
#define VCERT_E_CMS_ASN1_ENCODE                0xE0700010L
#define VCERT_E_SIGN_HASH                      0xE0700012L
#define VCERT_E_VERIFY_POLICY                  0xE0700013L
#define VCERT_E_VERIFY_EXTKEYUSAGE             0xE0700014L
#define VCERT_E_OVERFLOW                       0xE0700016L
#define VCERT_E_PKCS10_DAMAGED                 0xE0700017L
#define VCERT_E_REVREQ_DAMAGED                 0xE0700018L
#define VCERT_E_VERIFY                         0xE0700019L
#define VCERT_E_CMS_INVALID_TYPE               0xE0700022L
#define VCERT_E_CMS_NO_RECIPIENTS              0xE0700024L
#define VCERT_E_CMS_NOT_RECIPIENT              0xE0700026L
#define VCERT_E_CMS_KEY_DECRYPT                0xE0700027L
#define VCERT_E_DATA_DECRYPT                   0xE0700028L
#define VCERT_E_RANDOM                         0xE0700029L
#define VCERT_E_OPEN_CONFIG                    0xE071002AL
#define VCERT_E_READ_CONFIG                    0xE071002BL
#define VCERT_E_NO_DEFAULT_CONFIG              0xE071002CL
#define VCERT_E_OPEN_PSESTORE                  0xE070002DL
#define VCERT_E_OPEN_LOCALSTORE                0xE070002EL
#define VCERT_E_VERIFY_STORE_USAGE             0xE070002FL
#define VCERT_E_VERIFY_STORE                   0xE0700030L
#define VCERT_E_OPEN_LDAPSTORE                 0xE0700031L
#define VCERT_E_VERIFY_CERT                    0xE0700034L
#define VCERT_E_CERT_MISSING                   0xE0700035L
#define VCERT_E_CERT_EXPIRED                   0xE0700036L
#define VCERT_E_CERT_DAMAGED                   0xE0700037L
#define VCERT_E_CERT_BROKEN_CONSTRAINT         0xE0700038L
#define VCERT_E_CERT_REVOKED                   0xE0700039L
#define VCERT_E_CERT_UNTRUSTED                 0xE070003AL
#define VCERT_E_CRL_MISSING                    0xE070003BL
#define VCERT_E_CRL_EXPIRED                    0xE070003CL
#define VCERT_E_CRL_DAMAGED                    0xE070003DL
#define VCERT_E_CERT_BROKEN_HIERARCHY          0xE070003EL
#define VCERT_E_CHAIN_ERROR                    0xE070003FL
#define VCERT_E_INVALID_USAGE                  0xE0700041L
#define VCERT_E_INVALID_SIGNATURE              0xE0700042L
#define VCERT_E_PUBKEY_NOT_FOUND               0xE0700043L
#define VCERT_E_UPDATECRL                      0xE0700045L
#define VCERT_E_CERT_NOT_FOUND                 0xE0700046L
#define VCERT_E_CERT_NOT_YET_VALID             0xE0700047L
#define VCERT_E_NO_ATTACHED_SIGNER             0xE070004AL
#define VCERT_E_KERBEROS_FAILURE               0xE070004BL
#define VCERT_E_KEY_EXPIRED                    0xE070004CL
#define VCERT_E_KEY_NOT_YET_VALID              0xE070004DL
#define VCERT_E_CRL_NOT_YET_VALID              0xE070004EL
#define VCERT_E_INIT_CSP                       0xE070004FL
#define VCERT_E_ENUM_OBJECTS                   0xE0700050L
#define VCERT_E_ENUM_NO_MORE                   0xE0700051L
#define VCERT_E_INVALID_X500_NAME              0xE0700052L
#define VCERT_E_INVALID_HEX_STRING             0xE0700053L
#define VCERT_E_CMS_STREAM_MISMATCH            0xE0700054L
#define VCERT_E_CMS_DETACH_MISMATCH            0xE0700055L
#define VCERT_E_CMS_INVALID_DIGESTS            0xE0700056L
#define VCERT_E_CMS_INVALID_SIGNERS            0xE0700057L
#define VCERT_E_CMS_INVALID_CIPHER             0xE0700058L
#define VCERT_E_CMS_DATA_SIGNING               0xE0700059L
#define VCERT_E_CMS_OMAC_MISMATCH              0xE070005AL
#define VCERT_E_FIND_SESSION                   0xE0700081L
#define VCERT_E_CMS_NOT_ENCRYPTED              0xE0700083L
#define VCERT_E_ADD_OBJECT                     0xE0700087L
#define VCERT_E_TOO_MANY_CERTS_FOUND           0xE0720089L
#define VCERT_E_USER_CANCEL                    0xE072008AL
#define VCERT_E_OPEN_INFILE                    0xE070008BL
#define VCERT_E_OPEN_OUTFILE                   0xE070008CL
#define VCERT_E_READ_FILE                      0xE070008DL
#define VCERT_E_WRITE_FILE                     0xE070008EL
#define VCERT_E_FILE_LENGTH                    0xE070008FL
#define VCERT_E_DELETE_OBJECT                  0xE0700091L
#define VCERT_E_TOO_FEW_SIGNATURES             0xE0700092L
#define VCERT_E_GET_PUBKEY                     0xE0700094L
#define VCERT_E_PKCS10_CREATE                  0xE0700098L
#define VCERT_E_PKCS10_SIGN                    0xE070009AL
#define VCERT_E_REVREQ_CREATE                  0xE070009BL
#define VCERT_E_REVREQ_SIGN                    0xE070009CL
#define VCERT_E_LOAD_PRIVATE_KEY               0xE070009DL
#define VCERT_E_ADD_SIGNER                     0xE070009EL
#define VCERT_E_OPEN_IDP                       0xE07000A1L
#define VCERT_E_READ_IDP                       0xE07000A2L
#define VCERT_E_INVALID_CREDENTIALS            0xE02000A8L
#define VCERT_E_ACCESS_DENIED                  0xE02000A9L
#define VCERT_E_SESSION_BLOCKED                0xA02000AAL
#define VCERT_E_CLIENT_INFO                    0xE02000ABL
#define VCERT_E_UNSECURE_CREDENTIALS           0xE02000ACL
#define VCERT_E_SESSION_TIMEOUT                0xA07000AEL
#define VCERT_E_TSP_HASH_LENGTH                0xE0700100L
#define VCERT_E_TSP_HASH_ALGORITHM             0xE0700101L
#define VCERT_E_TSP_CERT_PURPOSE               0xE0700102L
#define VCERT_E_TSP_SIGN_FAILED                0xE0700103L
#define VCERT_E_TSP_NO_DIGEST                  0xE0700104L
#define VCERT_E_TSP_INVALID_SIGNER_NUM         0xE0700105L
#define VCERT_E_TSP_NO_TST_INFO                0xE0700106L
#define VCERT_E_TSP_RESP_ASN1_DECODE           0xE0700107L
#define VCERT_E_TSP_RESP_NOT_ISSUED            0xE0700108L
#define VCERT_E_TSP_DIGEST_MISMATCH            0xE0700109L
#define VCERT_E_TSP_INCORRECT_NONCE            0xE070010AL
#define VCERT_E_OCSP_CERT_PURPOSE              0xE0700140L
#define VCERT_E_OCSP_SIGN_FAILED               0xE0700141L
#define VCERT_E_OCSP_RESP_ASN1_DECODE          0xE0700142L
#define VCERT_E_OCSP_RESP_NOT_ISSUED           0xE0700143L
#define VCERT_E_OCSP_NOT_BASICRESP             0xE0700144L
#define VCERT_E_OCSP_CERTID_MISMATCH           0xE0700145L
#define VCERT_E_OCSP_ISSUER_MISMATCH           0xE0700146L
#define VCERT_E_OCSP_INCORRECT_NONCE           0xE0700147L
#define VCERT_E_TLS_UNSUPPORTED                0xE0700180L
#define VCERT_E_TLS_NEW_CONTEXT                0xE0700181L
#define VCERT_E_TLS_INVALID_STATE              0xE0700182L
#define VCERT_E_TLS_HANDSHAKE                  0xE0700183L
#define VCERT_E_TLS_NOT_COMPLETE               0xE0700184L
#define VCERT_E_TLS_NO_QUERY_DATA              0xE0700185L
#define VCERT_E_TLS_WRONG_CERT                 0xE0700186L
#define VCERT_E_TLS_WRONG_NAME                 0xE0700187L
#define VCERT_E_TLS_WRITE_ERROR                0xE0700188L
#define VCERT_E_TLS_READ_ERROR                 0xE0700189L
#define VCERT_E_TLS_READ_MORE                  0xE0700190L

/*
 * ���������� ���������� ��������� [������]
 */

#ifndef _VD_DIS_DEPR

#define VCERT_E_HASH                           0xE0700007L
#define VCERT_E_PKCS7_SET_TYPE                 0xE070000AL
#define VCERT_E_PKCS7_ADD_SIGNATURE            0xE070000CL
#define VCERT_E_PKCS7_ADD_CERTIFICATE          0xE070000DL
#define VCERT_E_PKCS7_CONTENT_NEW              0xE070000EL
#define VCERT_E_PKCS7_D2I                      0xE070000FL
#define VCERT_E_PKCS7_I2D                      0xE0700010L
#define VCERT_E_PKEY_NOT_GOST                  0xE0700011L
#define VCERT_E_SIGN                           0xE0700012L
#define VCERT_E_PKCS7_READ                     0xE0700015L
#define VCERT_E_REQ_DAMAGED                    0xE0700017L
#define VCERT_E_VERIFY_FORMAT                  0xE070001AL
#define VCERT_E_DELETE_SIGN                    0xE070001BL
#define VCERT_E_PKCS7_SET_CIPHER               0xE070001DL
#define VCERT_E_PKCS7_SET_CIPHER_INFO          0xE070001EL
#define VCERT_E_PKCS7_ADD_RECIPIENT            0xE070001FL
#define VCERT_E_PKCS7_ENCRYPT                  0xE0700020L
#define VCERT_E_PKCS7_WRONG_TYPE               0xE0700022L
#define VCERT_E_EVP_GET_CIPHER                 0xE0700023L
#define VCERT_E_DECRYPT_NO_RECIPIENTS          0xE0700024L
#define VCERT_E_DECRYPT_NO_SENDER              0xE0700025L
#define VCERT_E_DECRYPT_NO_RECIPIENT           0xE0700026L
#define VCERT_E_PKCS7_DECRYPT                  0xE0700027L
#define VCERT_E_DECRYPT                        0xE0700028L
#define VCERT_E_OPEN_PSE                       0xE070002DL
#define VCERT_E_NO_STREAM_DATA                 0xE0700032L
#define VCERT_E_BAD_STREAM_EOC                 0xE0700033L
#define VCERT_E_OPENKEY_NOT_FOUND              0xE0700043L
#define VCERT_E_REQ_NOT_FOUND                  0xE0700048L
#define VCERT_E_PKCS7_WRONG_ALGORITHM          0xE0700049L
#define VCERT_E_SIGNLEN                        0xE0700082L
#define VCERT_E_DECRYPT_FORMAT                 0xE0700083L
#define VCERT_E_FILE_MAPPING                   0xE0700090L
#define VCERT_E_INSUFFICIENT_SIGNS             0xE0700092L
#define VCERT_E_VERIFY_CRL                     0xE0700093L
#define VCERT_E_REQ_NEW                        0xE0700098L
#define VCERT_E_REQ_SIGN                       0xE070009AL
#define VCERT_E_MAKE_REVREQ                    0xE070009BL
#define VCERT_E_SIGN_REVREQ                    0xE070009CL
#define VCERT_E_PKCS7_DATA_INIT                0xE070009FL
#define VCERT_E_BIO_WRITE                      0xE07000A0L
#define VCERT_E_RESIGN_PROHIBIT                0xE02000ADL
#define VCERT_E_TSP_RESP_D2I                   0xE0700107L
#define VCERT_E_OCSP_RESP_D2I                  0xE0700142L

#endif /* !_VD_DIS_DEPR */

/*
 * ���������� ���������� ��������� [�����]
 */

#endif /* _VCERTERR_H_ */
