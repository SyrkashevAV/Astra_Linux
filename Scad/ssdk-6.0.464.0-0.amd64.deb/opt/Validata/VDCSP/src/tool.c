/*
 * Copyright (C) �� ����� 1997-1999
 * Copyright (C) �������� 1999-2018
 * ��� 䠩� ᮤ�ন� ���ଠ��,
 * ������� ᮡ�⢥������� �������� ��������.
 *
 * �� ���� �⮣� 䠩�� �� ����� ���� ᪮��஢���,
 * ��ࠢ����, ��ॢ����� �� ��㣨� �모,
 * ������������ ��� ������஢��� ��� ᯮᮡ��,
 * �⪮�����஢���, ��।��� �� �� � ��� ��
 * ���� ���������� ��⥬� ��� �।���⥫쭮��
 * �����祭�� ᮣ��襭�� � ��������� ��������.
 */

/******************************************************************************/

#include "util.h"

/******************************************************************************/

static mem_blk_t msig = { 0, (void *) -1 };
static mem_blk_t mdat = { 0, (void *) -1 };

/******************************************************************************/

static mem_blk_t mcer[MAX_NUM] = { { 0, (void *) -1 } };
static mem_blk_t mcrl[MAX_NUM] = { { 0, (void *) -1 } };
static int       ncer          = 0;
static int       ncrl          = 0;

/******************************************************************************/

#ifdef _WIN32

/******************************************************************************/

#define TIME_T    LARGE_INTEGER

static void
tinit(
    TIME_T * tim)
{
    QueryPerformanceCounter(tim);
}

/******************************************************************************/

static float
tfini(
    TIME_T * tim)
{
    TIME_T        dif;
    LARGE_INTEGER frq;

    QueryPerformanceCounter(&dif);

    dif.QuadPart -= tim->QuadPart;
    dif.QuadPart *= 1000;

    QueryPerformanceFrequency(&frq);

    return ((float) (dif.QuadPart / frq.QuadPart));
}

/******************************************************************************/

#else  /* _WIN32 */

/******************************************************************************/

#define TIME_T    struct timeval

static void
tinit(
    TIME_T * tim)
{
    gettimeofday(tim, NULL);
}

/******************************************************************************/

static float
tfini(
    TIME_T * tim)
{
    TIME_T dif;

    gettimeofday(&dif, NULL);

    return ((float) (dif.tv_sec  - tim->tv_sec )) * 1000 +
           ((float) (dif.tv_usec - tim->tv_usec)) / 1000;
}

/******************************************************************************/

#endif /* _WIN32 */

/******************************************************************************/

#ifdef _WIN32

static unsigned int WINAPI
doit(
    void * param)

#else  /* _WIN32 */

static void *
doit(
    void * param)

#endif /* _WIN32 */
{
    error_status_t rc    = VCERT_E_GENERIC;
    const char     * ops = NULL;
    TIME_T         tim;
    float          spd;
    int            idx;

    if (ophash)
    {
#ifdef RUSSIAN
        if (stream)
            ops = "��⮪���� ���᫥��� ���-���祭��";
        else
            ops = "���筮� ���᫥��� ���-���祭��";
#else
        if (stream)
            ops = "Stream hash calculation";
        else
            ops = "Block hash calculation";
#endif
    }
    else if (opsign)
    {
#ifdef RUSSIAN
        if (stream)
        {
            if (detached)
                ops = "��⮪���� ���᫥��� ��ᮥ�������� ��";
            else
                ops = "��⮪���� ���᫥��� ��ᮥ�������� ��";
        }
        else
            if (detached)
                ops = "���筮� ���᫥��� ��ᮥ�������� ��";
            else
                ops = "���筮� ���᫥��� ��ᮥ�������� ��";
#else
        if (stream)
        {
            if (detached)
                ops = "Stream detached signing";
            else
                ops = "Stream attached signing";
        }
        else
            if (detached)
                ops = "Block detached signing";
            else
                ops = "Block attached signing";
#endif
    }
    else if (opvrfy)
    {
#ifdef RUSSIAN
        if (stream)
        {
            if (detached)
                ops = "��⮪���� �஢�ઠ ��ᮥ�������� ��";
            else
                ops = "��⮪���� �஢�ઠ ��ᮥ�������� ��";
        }
        else
            if (detached)
                ops = "���筠� �஢�ઠ ��ᮥ�������� ��";
            else
                ops = "���筠� �஢�ઠ ��ᮥ�������� ��";
#else
        if (stream)
        {
            if (detached)
                ops = "Stream detached signature verification";
            else
                ops = "Stream attached signature verification";
        }
        else
            if (detached)
                ops = "Block detached signature verification";
            else
                ops = "Block attached signature verification";
#endif
    }
    else if (opencr)
    {
#ifdef RUSSIAN
        if (stream)
            ops = "��⮪���� ����஢����";
        else
            ops = "���筮� ����஢����";
#else
        if (stream)
            ops = "Stream encryption";
        else
            ops = "Block encryption";
#endif
    }
    else if (opdecr)
    {
#ifdef RUSSIAN
        if (stream)
            ops = "��⮪���� ����஢����";
        else
            ops = "���筮� ����஢����";
#else
        if (stream)
            ops = "Stream decryption";
        else
            ops = "Block decryption";
#endif
    }
    else if (optssg)
    {
#ifdef RUSSIAN
        if (stream)
            ops = "��⮪���� ����祭�� �⠬�� �६���";
        else
            ops = "���筮� ����祭�� �⠬�� �६���";
#else
        if (stream)
            ops = "Stream time stamp signing";
        else
            ops = "Block time stamp signing";
#endif
    }
    else if (opocin)
    {
#ifdef RUSSIAN
        ops = "����祭�� ����� ���䨪��";
#else
        ops = "Online certificate status";
#endif
    }
    else if (opfncr)
    {
#ifdef RUSSIAN
        ops = "���� ���䨪�⮢ � �ࠢ�筨���";
#else
        ops = "Search for certificates in stores";
#endif
    }

    tinit(&tim);

    for (idx = 0; idx < iterat; idx ++)
    {
        if (ophash)
        {
            strhash_t hstr = NULL;
            mem_blk_t mout = { 0 };

            if (stream)
                do
                {
                    rc = VCERT_StrHashInitMem(hCtx[0], algorithm, &hstr);
                    if (rc)
                        break;
                    rc = VCERT_StrHashUpdateMem(hCtx[0], &hstr, &mdat);
                    if (rc)
                        break;
                    rc = VCERT_StrHashFinalMem(hCtx[0], &hstr, &mout);
                }
                while (0);
            else
                rc = VCERT_BlkHashMem(hCtx[0], algorithm, &mdat, &mout);

            VCERT_FreeMem(hCtx[0], mout.buf),
                memset(&mout, 0, sizeof(mem_blk_t));
        }
        else if (opsign)
        {
            strcms_t  hstr = NULL;
            mem_blk_t mout = { 0 };
            mem_blk_t mtmp = { 0 };

            if (stream)
            {
                if (detached)
                    do
                    {
                        rc = VCERT_CmsStrDetSignInitMem(hCtx[0], &sign_p, &mtmp, &hstr);
                        if (rc)
                            break;
                        rc = VCERT_CmsStrDetSignUpdateMem(hCtx[0], &sign_p, &hstr, &mdat);
                        if (rc)
                            break;
                        rc = VCERT_CmsStrDetSignFinalMem(hCtx[0], &sign_p, &hstr, &mout);
                    }
                    while (0);
                else
                    do
                    {
                        rc = VCERT_CmsStrAttSignInitMem(hCtx[0], &sign_p, &mdat, &hstr);
                        if (rc)
                            break;
                        rc = VCERT_CmsStrAttSignUpdateMem(hCtx[0], &sign_p, &hstr, &mtmp, &mtmp);
                        if (rc)
                            break;
                        rc = VCERT_CmsStrAttSignFinalMem(hCtx[0], &sign_p, &hstr, &mout);
                    }
                    while (0);
            }
            else
                if (detached)
                    rc = VCERT_CmsBlkDetSignMem(hCtx[0], &sign_p, &mdat, &mtmp, &mout);
                else
                    rc = VCERT_CmsBlkAttSignMem(hCtx[0], &sign_p, &mdat, &mout);

            VCERT_FreeMem(hCtx[0], mout.buf),
                memset(&mout, 0, sizeof(mem_blk_t));

            VCERT_FreeMem(hCtx[0], mtmp.buf),
                memset(&mtmp, 0, sizeof(mem_blk_t));
        }
        else if (opvrfy)
        {
            strcms_t        hstr = NULL;
            mem_blk_t       mout = { 0 };
            mem_blk_t       mtmp = { 0 };
            verify_result_t vres = { 0 };

            if (stream)
            {
                if (detached)
                    do
                    {
                        rc = VCERT_CmsStrDetVerifyInitMem(hCtx[0], &verify_p, &msig, &hstr);
                        if (rc)
                            break;
                        rc = VCERT_CmsStrDetVerifyUpdateMem(hCtx[0], &verify_p, &hstr, &mdat);
                        if (rc)
                            break;
                        rc = VCERT_CmsStrDetVerifyFinalMem(hCtx[0], &verify_p, &hstr, &mout, &vres);
                    }
                    while (0);
                else
                    do
                    {
                        rc = VCERT_CmsStrAttVerifyInitMem(hCtx[0], &verify_p, &mdat, &hstr);
                        if (rc)
                            break;
                        rc = VCERT_CmsStrAttVerifyUpdateMem(hCtx[0], &verify_p, &hstr, &mtmp, &mtmp);
                        if (rc)
                            break;
                        rc = VCERT_CmsStrAttVerifyFinalMem(hCtx[0], &verify_p, &hstr, &mout, &vres);
                    }
                    while (0);
            }
            else
                if (detached)
                    rc = VCERT_CmsBlkDetVerifyMem(hCtx[0], &verify_p, &mdat, &msig, &mout, &vres);
                else
                    rc = VCERT_CmsBlkAttVerifyMem(hCtx[0], &verify_p, &mdat, &mout, &vres);

            VCERT_FreeMem(hCtx[0], mout.buf),
                memset(&mout, 0, sizeof(mem_blk_t));

            VCERT_FreeMem(hCtx[0], mtmp.buf),
                memset(&mtmp, 0, sizeof(mem_blk_t));

            VCERT_FreeVerifyResult(hCtx[0], &vres),
                memset(&vres, 0, sizeof(verify_result_t));
        }
        else if (opencr)
        {
            strcms_t  hstr = NULL;
            mem_blk_t mout = { 0 };
            mem_blk_t mtmp = { 0 };

            if (stream)
            {
                do
                {
                    rc = VCERT_CmsStrEncryptInitMem(hCtx[0], &encrypt_p, &mdat, &hstr);
                    if (rc)
                        break;
                    rc = VCERT_CmsStrEncryptUpdateMem(hCtx[0], &encrypt_p, &hstr, &mtmp, &mtmp);
                    if (rc)
                        break;
                    rc = VCERT_CmsStrEncryptFinalMem(hCtx[0], &encrypt_p, &hstr, &mout);
                }
                while (0);
            }
            else
                rc = VCERT_CmsBlkEncryptMem(hCtx[0], &encrypt_p, &mdat, &mout);

            VCERT_FreeMem(hCtx[0], mout.buf),
                memset(&mout, 0, sizeof(mem_blk_t));

            VCERT_FreeMem(hCtx[0], mtmp.buf),
                memset(&mtmp, 0, sizeof(mem_blk_t));
        }
        else if (opdecr)
        {
            strcms_t         hstr = NULL;
            mem_blk_t        mout = { 0 };
            mem_blk_t        mtmp = { 0 };
            decrypt_result_t dres = { { 0 } };

            if (stream)
            {
                do
                {
                    rc = VCERT_CmsStrDecryptInitMem(hCtx[0], &decrypt_p, &mdat, &hstr);
                    if (rc)
                        break;
                    rc = VCERT_CmsStrDecryptUpdateMem(hCtx[0], &decrypt_p, &hstr, &mtmp, &mtmp);
                    if (rc)
                        break;
                    rc = VCERT_CmsStrDecryptFinalMem(hCtx[0], &decrypt_p, &hstr, &mout, &dres);
                }
                while (0);
            }
            else
                rc = VCERT_CmsBlkDecryptMem(hCtx[0], &decrypt_p, &mdat, &mout, &dres);

            VCERT_FreeMem(hCtx[0], mout.buf),
                memset(&mout, 0, sizeof(mem_blk_t));

            VCERT_FreeMem(hCtx[0], mtmp.buf),
                memset(&mtmp, 0, sizeof(mem_blk_t));

            VCERT_FreeDecryptResult(hCtx[0], &dres),
                memset(&dres, 0, sizeof(decrypt_result_t));
        }
        else if (optssg)
        {
            strcms_t  hstr = NULL;
            mem_blk_t mout = { 0 };
            mem_blk_t mtmp = { 0 };

            if (stream)
            {
                do
                {
                    rc = VCERT_TspStrUrlStampCmsInitMem(hCtx[0], &tssign_p, url, &mdat, &hstr);
                    if (rc)
                        break;
                    rc = VCERT_TspStrUrlStampCmsUpdateMem(hCtx[0], &tssign_p, url, &hstr, &mtmp, &mtmp);
                    if (rc)
                        break;
                    rc = VCERT_TspStrUrlStampCmsFinalMem(hCtx[0], &tssign_p, url, &hstr, &mout);
                }
                while (0);
            }
            else
                rc = VCERT_TspBlkUrlStampCmsMem(hCtx[0], &tssign_p, url, &mdat, &mout);

            VCERT_FreeMem(hCtx[0], mout.buf),
                memset(&mout, 0, sizeof(mem_blk_t));

            VCERT_FreeMem(hCtx[0], mtmp.buf),
                memset(&mtmp, 0, sizeof(mem_blk_t));
        }
        else if (opocin)
        {
            mem_blk_t mout = { 0 };

            rc = VCERT_OcspUrlObtainResponse(hCtx[0], &ocspsig_p, url, &mdat, &mout);

            VCERT_FreeMem(hCtx[0], mout.buf),
                memset(&mout, 0, sizeof(mem_blk_t));
        }
        else if (opfncr)
        {
            find_result_t fres = { 0 };

            rc = VCERT_FindCert(hCtx[0], &find_p, &fres);

            VCERT_FreeFindResult(hCtx[0], &fres),
                memset(&fres, 0, sizeof(find_result_t));
        }

        if (rc && rc != VCERT_E_VERIFY && rc != VCERT_E_CERT_NOT_FOUND)
            break;
    }

    spd = tfini(&tim);
    spd = (spd > 0 ? spd : 1000) / 1000;

    do
    {
        char fmt[MAX_NUM];

#ifdef RUSSIAN
        if (opfncr)
            sprintf(fmt, "[% 3ld] %s: %.3f ᥪ. ; %.3f ��./ᥪ.\n",
                    (long) param + 1, ops, spd, (float) iterat / spd);
        else
            sprintf(fmt, "[% 3ld] %s: %.3f ᥪ. ; %.3f ��./ᥪ. ; %.3f ��./ᥪ.\n",
                    (long) param + 1, ops, spd, (float) iterat / spd,
                    (float) iterat * (float) mdat.len / (1024 * spd));
#else
        if (opfncr)
            sprintf(fmt, "[% 3ld] %s: %.3f sec. ; %.3f op./sec.\n",
                    (long) param + 1, ops, spd, (float) iterat / spd);
        else
            sprintf(fmt, "[% 3ld] %s: %.3f sec. ; %.3f op./sec. ; %.3f Kb./sec.\n",
                    (long) param + 1, ops, spd, (float) iterat / spd,
                    (float) iterat * (float) mdat.len / (1024 * spd));
#endif

        file_print(flog, fmt);

        status_print(flog, rc, (long) param + 1);
    }
    while (0);

#ifdef _WIN32
    return rc;
#else  /* _WIN32 */
    return NULL;
#endif /* _WIN32 */
}

/******************************************************************************/

int
tools_main(
    int argc,
    char ** argv)
{
    unsigned long rc = VCERT_E_GENERIC;
    int           idx, chr;

    char          * strloc = NULL;

    static struct option long_options[] =
    {
        { "attach",    no_argument,       NULL, 0x1001 },
        { "detach",    no_argument,       NULL, 0x1002 },
        { "enuobj",    no_argument,       NULL, 0x1003 },
        { "findcer",   no_argument,       NULL, 0x1004 },
        { "speed",     no_argument,       NULL, 0x1005 },
        { "enuprof",   no_argument,       NULL, 0x1006 },
        { "creprof",   no_argument,       NULL, 0x1007 },
        { "crestor",   no_argument,       NULL, 0x1008 },
        { "impobj",    no_argument,       NULL, 0x1009 },
        { "expreq",    no_argument,       NULL, 0x100A },

        { "query",     required_argument, NULL, 0x2001 },
        { "subject",   required_argument, NULL, 0x2002 },
        { "issuer",    required_argument, NULL, 0x2003 },
        { "serial",    required_argument, NULL, 0x2004 },
        { "cerhash",   required_argument, NULL, 0x2005 },
        { "email",     required_argument, NULL, 0x2006 },
        { "keyid",     required_argument, NULL, 0x2007 },
        { "subjkid",   required_argument, NULL, 0x2008 },

        { "iterat",    required_argument, NULL, 0x3001 },
        { "threads",   required_argument, NULL, 0x3002 },

        { "uripse",    required_argument, NULL, 0x4001 },
        { "uriloc",    required_argument, NULL, 0x4002 },
        { "urildp",    required_argument, NULL, 0x4003 },
        { "dercer",    required_argument, NULL, 0x4004 },
        { "dercrl",    required_argument, NULL, 0x4005 },

        { "showui",    no_argument,       NULL, 0x5001 },
        { "signer",    no_argument,       NULL, 0x5002 },
        { "remote",    no_argument,       NULL, 0x5003 },
        { "512bit",    no_argument,       NULL, 0x5004 },
        { "cargen",    no_argument,       NULL, 0x5005 },
        { "revoke",    no_argument,       NULL, 0x5006 },

        { "help",      no_argument,       NULL,    '?' },

        {           0,                 0,    0,      0 }
    };

    while ((chr = getopt_long_only(argc, argv, "", long_options, (int *) 0)) != EOF)
    {
        switch (chr)
        {
        case 0x1001:
            opatta = 1;
            break;

        case 0x1002:
            opdeta = 1;
            break;

        case 0x1003:
            openob = 1;
            break;

        case 0x1004:
            opfncr = 1;
            break;

        case 0x1005:
            opsped = 1;
            break;

        case 0x1006:
            openpr = 1;
            break;

        case 0x1007:
            opcrpr = 1;
            break;

        case 0x1008:
            opcrst = 1;
            break;

        case 0x1009:
            opimob = 1;
            break;

        case 0x100A:
            opexrq = 1;
            break;


        case 0x2001:
            query = (string_t) (strloc = oem_to_char(optarg));
            if (strloc != optarg)
                ;
            else
                query = NULL;
            break;

        case 0x2002:
            find_p.certTemplate.subject = (string_t) (strloc = oem_to_char(optarg));
            if (strloc != optarg)
                find_p.certTemplate.fields |= FIELD_SUBJECT;
            else
                find_p.certTemplate.subject = NULL;
            break;

        case 0x2003:
            find_p.certTemplate.issuer = (string_t) (strloc = oem_to_char(optarg));
            if (strloc != optarg)
                find_p.certTemplate.fields |= FIELD_ISSUER;
            else
                find_p.certTemplate.issuer = NULL;
            break;

        case 0x2004:
            find_p.certTemplate.serialNumber = (string_t) (strloc = oem_to_char(optarg));
            if (strloc != optarg)
                find_p.certTemplate.fields |= FIELD_SERIAL;
            else
                find_p.certTemplate.serialNumber = NULL;
            break;

        case 0x2005:
            find_p.certTemplate.certHash.buf = string2hex(optarg, (int *) &find_p.certTemplate.certHash.len);
            if (find_p.certTemplate.certHash.buf)
                find_p.certTemplate.fields |= FIELD_CERTHASH;
            break;

        case 0x2006:
            find_p.certTemplate.subjectAltName.emailAddress = (string_t) (strloc = oem_to_char(optarg));
            if (strloc != optarg)
                find_p.certTemplate.fields |= FIELD_SUBJECTALTNAME;
            else
                find_p.certTemplate.subjectAltName.emailAddress = NULL;
            break;

        case 0x2007:
            find_p.certTemplate.keyId = (string_t) (strloc = oem_to_char(optarg));
            if (strloc != optarg)
                find_p.certTemplate.fields |= FIELD_KEYID;
            else
                find_p.certTemplate.keyId = NULL;
            break;

        case 0x2008:
            extn_p.oid      = (string_t) "2.5.29.14";
            extn_p.type     = 4; /* ASN.1 OCTET STRING */
            extn_p.critical = 0;
            extn_p.data     = string2hex(optarg, (int *) &extn_p.len);
            if (extn_p.data)
            {
                find_p.certTemplate.fields       |= FIELD_EXTENSIONS;
                find_p.certTemplate.extension_num = 1;
                find_p.certTemplate.extensions    = &extn_p;
            }
            break;


        case 0x3001:
            iterat = atoi(optarg);
            if (iterat < 1)
                iterat = 100;
            break;

        case 0x3002:
            threads = atoi(optarg);
            if (threads < 1 || threads > MAX_NUM)
                threads = 1;
            break;


        case 0x4001:
            uripse = optarg;
            break;

        case 0x4002:
            uriloc = optarg;
            break;

        case 0x4003:
            urildp = optarg;
            break;

        case 0x4004:
            if (ncer < MAX_NUM)
            {
                rc = file_mmap(optarg, (void **) &mcer[ncer].buf, (int *) &mcer[ncer].len);
                if (rc)
                    goto err;
                ncer ++;
            }
            break;

        case 0x4005:
            if (ncrl < MAX_NUM)
            {
                rc = file_mmap(optarg, (void **) &mcrl[ncrl].buf, (int *) &mcrl[ncrl].len);
                if (rc)
                    goto err;
                ncrl ++;
            }
            break;


        case 0x5001:
            import_p.flag |= FLAG_IMPORT_DISPLAYOBJECTUI;
            export_p.flag |= FLAG_EXPORT_SHOWREQUESTUI;
            break;

        case 0x5002:
            import_p.flag |= FLAG_IMPORT_CERTWITHPRIVATE;
            break;

        case 0x5003:
            import_p.flag |= FLAG_IMPORT_FORCEREMOTESTORE;
            break;

        case 0x5004:
            export_p.flag |= FLAG_EXPORT_GOST_R_34_10_12_512;
            break;

        case 0x5005:
            export_p.flag |= FLAG_EXPORT_CARRIER_GENERATION;
            break;

        case 0x5006:
            export_p.flag |= FLAG_EXPORT_REVOKEREQUEST;
            break;


        default:
        case '?':
            print_help = 1;
            goto err;
        }
    }
    if (chr != EOF)
    {
        print_help = 1;
        goto err;
    }

    if (opsped)
    {
        if ((opatta ? 1 : 0) + (opdeta ? 1 : 0) + (openob ? 1 : 0) +
            (openpr ? 1 : 0) + (opcrpr ? 1 : 0) + (opcrst ? 1 : 0) +
            (opimob ? 1 : 0) + (opexrq ? 1 : 0) > 0)
        {
            print_help = 1;
            goto err;
        }
        if ((ophash ? 1 : 0) + (opsign ? 1 : 0) + (opvrfy ? 1 : 0) +
            (opencr ? 1 : 0) + (opdecr ? 1 : 0) + (optssg ? 1 : 0) +
            (opocin ? 1 : 0) + (opfncr ? 1 : 0) != 1)
        {
            print_help = 1;
            goto err;
        }
        if (!finp && opvrfy && detached)
        {
            print_help = 1;
            goto err;
        }
        if (!fdat && !opfncr)
        {
            print_help = 1;
            goto err;
        }
    }
    else
    {
        if ((opatta ? 1 : 0) + (opdeta ? 1 : 0) + (openob ? 1 : 0) +
            (opfncr ? 1 : 0) + (openpr ? 1 : 0) + (opcrpr ? 1 : 0) +
            (opcrst ? 1 : 0) + (opimob ? 1 : 0) + (opexrq ? 1 : 0) != 1)
        {
            print_help = 1;
            goto err;
        }
        if ((ophash ? 1 : 0) + (opsign ? 1 : 0) + (opvrfy ? 1 : 0) +
            (opencr ? 1 : 0) + (opdecr ? 1 : 0) > 0)
        {
            print_help = 1;
            goto err;
        }
        if (!finp && (opatta ||
                      opdeta ||
                      opimob))
        {
            print_help = 1;
            goto err;
        }
        if (!fout && (opatta ||
                      opdeta ||
                      opexrq))
        {
            print_help = 1;
            goto err;
        }
        if (!fdat && (opatta ||
                      opdeta))
        {
            print_help = 1;
            goto err;
        }
    }

    if (opsped)
    {
#ifdef _WIN32
        HANDLE    hthr[MAX_NUM] = { 0 };
        DWORD     ithr[MAX_NUM] = { 0 };
#else  /* _WIN32 */
        pthread_t hthr[MAX_NUM];
        void      * stat;
#endif /* _WIN32 */
        int       indx;

        if (opvrfy && detached)
        {
            rc = file_mmap(finp, (void **) &msig.buf, (int *) &msig.len);
            if (rc)
                goto err;
        }

        if (!opfncr)
        {
            rc = file_mmap(fdat, (void **) &mdat.buf, (int *) &mdat.len);
            if (rc)
                goto err;
        }

        for (indx = 0; indx < 1024 /* == 2 * ���ᨬ��쭮� ������⢮ ��� */; indx ++)
        {
            mem_blk_t rand = { 0 };

            (void) VCERT_GenRandom(hCtx[0], 32, &rand);

            VCERT_FreeMem(hCtx[0], rand.buf);
        }

#ifdef RUSSIAN
        file_print(flog, "\n�믮������ ᪮��⭮�� ��� [��ꥬ ������: %d ; ����権: %d ; ��⮪��: %d]\n\n",
                   msig.len + mdat.len, iterat, threads);
#else
        file_print(flog, "\nSpeed test execution [data size: %d ; iterations: %d ; threads: %d]\n\n",
                   msig.len + mdat.len, iterat, threads);
#endif

#ifdef _WIN32
        for (indx = 0; indx < threads; indx ++)
            hthr[indx] = (HANDLE) _beginthreadex(NULL, 0, doit, (void *) (size_t) indx, 0, &ithr[indx]);

        for (indx = 0; indx < threads; indx += MAXIMUM_WAIT_OBJECTS)
        {
            INT cnt = (threads - indx) < MAXIMUM_WAIT_OBJECTS ? (threads - indx) : MAXIMUM_WAIT_OBJECTS;

            if (WaitForMultipleObjects(cnt, (CONST HANDLE *) &hthr[indx], TRUE, INFINITE) == WAIT_FAILED)
            {
                rc = GetLastError();
                goto err;
            }
        }
#else  /* _WIN32 */
        for (indx = 0; indx < threads; indx ++)
            pthread_create(&hthr[indx], NULL, doit, (void *) (size_t) indx);

        for (indx = 0; indx < threads; indx ++)
            pthread_join(hthr[indx], &stat);
#endif /* _WIN32 */

        rc = 0;
    }
    else if (opatta)
    {
#ifdef RUSSIAN
        file_print(flog, "\n��ᮥ������� �� � �������ᠭ���� 䠩��\n");
#else
        file_print(flog, "\nAttach signature(s) to unsigned file\n");
#endif
        rc = VCERT_CmsBlkSignAttachFile(
            hCtx[0],
            fdat,
            finp,
            fout,
            0);
    }
    else if (opdeta)
    {
#ifdef RUSSIAN
        if (stream)
            file_print(flog, "\n��⮪���� ��ᮥ������� �� �� �����ᠭ���� 䠩��\n");
        else
            file_print(flog, "\n��ᮥ������� �� �� �����ᠭ���� 䠩��\n");
#else
        file_print(flog, "\nDetach signature(s) from signed file\n", (stream ? "Stream-" : ""));
#endif
        if (stream)
            rc = VCERT_CmsStrSignDetachFile(
                hCtx[0],
                finp,
                fdat,
                fout,
                0);
        else
            rc = VCERT_CmsBlkSignDetachFile(
                hCtx[0],
                finp,
                fdat,
                fout,
                0);
    }
    else if (openob)
    {
        enuobj_t      henu = NULL;
        certificate_t scer = { 0 };
        crl_t         scrl = { 0 };
        mem_blk_t     smem = { 0 };

        if (url)
        {
#ifdef RUSSIAN
            file_print(flog, "\n��ॡ�� ���䨪�⮢ � �ࠢ�筨�� \"%s\":\n", url);
#else
            file_print(flog, "\nStore \"%s\" certificate enumeration:\n", url);
#endif
            for (rc = 0, henu = NULL, idx = 0; !rc; idx ++)
            {
                VCERT_FreeCert(hCtx[0], &scer), VCERT_FreeMem(hCtx[0], smem.buf), smem.buf = NULL, smem.len = 0;

                rc = VCERT_EnumStoreObjectsEx(hCtx[0], &certid, url, query, &henu, &smem, FLAG_ENUM_STORE_OBJECTS_STORE_SURI |
                                                                                          FLAG_ENUM_STORE_OBJECTS_OBJECT_CER);
                if (!rc)
                    rc = VCERT_ParseCert(hCtx[0], &smem, fields | FIELD_ALGORITHM_OID_FORMAT, &scer);
                if (!rc)
                {
#ifdef RUSSIAN
                    file_print(flog, "\n����䨪�� �%d:\n", idx + 1);
#else
                    file_print(flog, "\nCertificate %d:\n", idx + 1);
#endif
                    certificate_print(flog, &scer);
                }
                else
                    if (rc != VCERT_E_ENUM_NO_MORE)
                        goto err;
            }

#ifdef RUSSIAN
            file_print(flog, "\n��ॡ�� ��� � �ࠢ�筨�� \"%s\":\n", url);
#else
            file_print(flog, "\nStore \"%s\" CRL enumeration:\n", url);
#endif
            for (rc = 0, henu = NULL, idx = 0; !rc; idx ++)
            {
                VCERT_FreeCrl(hCtx[0], &scrl), VCERT_FreeMem(hCtx[0], smem.buf), smem.buf = NULL, smem.len = 0;

                rc = VCERT_EnumStoreObjectsEx(hCtx[0], &certid, url, query, &henu, &smem, FLAG_ENUM_STORE_OBJECTS_STORE_SURI |
                                                                                          FLAG_ENUM_STORE_OBJECTS_OBJECT_CRL);
                if (!rc)
                    rc = VCERT_ParseCrl(hCtx[0], &smem, FIELD_CRL_ALL, &scrl);
                if (!rc)
                {
#ifdef RUSSIAN
                    file_print(flog, "\n��� �%d:\n", idx + 1);
#else
                    file_print(flog, "\nCRL %d:\n", idx + 1);
#endif
                    crl_print(flog, &scrl);
                }
                else
                    if (rc != VCERT_E_ENUM_NO_MORE)
                        goto err;
            }
        }
        else
        {
#ifdef RUSSIAN
            file_print(flog, "\n��ॡ�� ���䨪�⮢ � ���:\n");
#else
            file_print(flog, "\nPSE certificate enumeration:\n");
#endif
            for (rc = 0, henu = NULL, idx = 0; !rc; idx ++)
            {
                VCERT_FreeCert(hCtx[0], &scer), VCERT_FreeMem(hCtx[0], smem.buf), smem.buf = NULL, smem.len = 0;

                rc = VCERT_EnumStoreObjects(hCtx[0], &certid, &henu, &smem, FLAG_ENUM_STORE_OBJECTS_STORE_PERS |
                                                                            FLAG_ENUM_STORE_OBJECTS_OBJECT_CER);
                if (!rc)
                    rc = VCERT_ParseCert(hCtx[0], &smem, fields | FIELD_ALGORITHM_OID_FORMAT, &scer);
                if (!rc)
                {
#ifdef RUSSIAN
                    file_print(flog, "\n����䨪�� �%d:\n", idx + 1);
#else
                    file_print(flog, "\nCertificate %d:\n", idx + 1);
#endif
                    certificate_print(flog, &scer);
                }
                else
                    if (rc != VCERT_E_ENUM_NO_MORE)
                        goto err;
            }

#ifdef RUSSIAN
            file_print(flog, "\n��ॡ�� ���䨪�⮢ � ���:\n");
#else
            file_print(flog, "\nLocal store certificate enumeration:\n");
#endif
            for (rc = 0, henu = NULL, idx = 0; !rc; idx ++)
            {
                VCERT_FreeCert(hCtx[0], &scer), VCERT_FreeMem(hCtx[0], smem.buf), smem.buf = NULL, smem.len = 0;

                rc = VCERT_EnumStoreObjects(hCtx[0], &certid, &henu, &smem, FLAG_ENUM_STORE_OBJECTS_STORE_LOCL |
                                                                            FLAG_ENUM_STORE_OBJECTS_OBJECT_CER);
                if (!rc)
                    rc = VCERT_ParseCert(hCtx[0], &smem, fields | FIELD_ALGORITHM_OID_FORMAT, &scer);
                if (!rc)
                {
#ifdef RUSSIAN
                    file_print(flog, "\n����䨪�� �%d:\n", idx + 1);
#else
                    file_print(flog, "\nCertificate %d:\n", idx + 1);
#endif
                    certificate_print(flog, &scer);
                }
                else
                    if (rc != VCERT_E_ENUM_NO_MORE)
                        goto err;
            }

#ifdef RUSSIAN
            file_print(flog, "\n��ॡ�� ��� � ���:\n");
#else
            file_print(flog, "\nLocal store CRL enumeration:\n");
#endif
            for (rc = 0, henu = NULL, idx = 0; !rc; idx ++)
            {
                VCERT_FreeCrl(hCtx[0], &scrl), VCERT_FreeMem(hCtx[0], smem.buf), smem.buf = NULL, smem.len = 0;

                rc = VCERT_EnumStoreObjects(hCtx[0], &certid, &henu, &smem, FLAG_ENUM_STORE_OBJECTS_STORE_LOCL |
                                                                            FLAG_ENUM_STORE_OBJECTS_OBJECT_CRL);
                if (!rc)
                    rc = VCERT_ParseCrl(hCtx[0], &smem, FIELD_CRL_ALL, &scrl);
                if (!rc)
                {
#ifdef RUSSIAN
                    file_print(flog, "\n��� �%d:\n", idx + 1);
#else
                    file_print(flog, "\nCRL %d:\n", idx + 1);
#endif
                    crl_print(flog, &scrl);
                }
                else
                    if (rc != VCERT_E_ENUM_NO_MORE)
                        goto err;
            }

            if (ldap)
            {
#ifdef RUSSIAN
                file_print(flog, "\n��ॡ�� ���䨪�⮢ � ���:\n");
#else
                file_print(flog, "\nLDAP store certificate enumeration:\n");
#endif
                for (rc = 0, henu = NULL, idx = 0; !rc; idx ++)
                {
                    VCERT_FreeCert(hCtx[0], &scer), VCERT_FreeMem(hCtx[0], smem.buf), smem.buf = NULL, smem.len = 0;

                    rc = VCERT_EnumStoreObjects(hCtx[0], &certid, &henu, &smem, FLAG_ENUM_STORE_OBJECTS_STORE_LDAP |
                                                                                FLAG_ENUM_STORE_OBJECTS_OBJECT_CER);
                    if (!rc)
                        rc = VCERT_ParseCert(hCtx[0], &smem, fields | FIELD_ALGORITHM_OID_FORMAT, &scer);
                    if (!rc)
                    {
#ifdef RUSSIAN
                        file_print(flog, "\n����䨪�� �%d:\n", idx + 1);
#else
                        file_print(flog, "\nCertificate %d:\n", idx + 1);
#endif
                        certificate_print(flog, &scer);
                    }
                    else
                        if (rc != VCERT_E_ENUM_NO_MORE)
                            goto err;
                }

#ifdef RUSSIAN
                file_print(flog, "\n��ॡ�� ��� � ���:\n");
#else
                file_print(flog, "\nLDAP store CRL enumeration:\n");
#endif
                for (rc = 0, henu = NULL, idx = 0; !rc; idx ++)
                {
                    VCERT_FreeCrl(hCtx[0], &scrl), VCERT_FreeMem(hCtx[0], smem.buf), smem.buf = NULL, smem.len = 0;

                    rc = VCERT_EnumStoreObjects(hCtx[0], &certid, &henu, &smem, FLAG_ENUM_STORE_OBJECTS_STORE_LDAP |
                                                                                FLAG_ENUM_STORE_OBJECTS_OBJECT_CRL);
                    if (!rc)
                        rc = VCERT_ParseCrl(hCtx[0], &smem, FIELD_CRL_ALL, &scrl);
                    if (!rc)
                    {
#ifdef RUSSIAN
                        file_print(flog, "\n��� �%d:\n", idx + 1);
#else
                        file_print(flog, "\nCRL %d:\n", idx + 1);
#endif
                        crl_print(flog, &scrl);
                    }
                    else
                        if (rc != VCERT_E_ENUM_NO_MORE)
                            goto err;
                }
            }
        }

        file_print(flog, "\n");
    }
    else if (opfncr)
    {
#ifdef RUSSIAN
        file_print(flog, "\n���� ���䨪�⮢ � ����㯭�� �ࠢ�筨���:\n");
#else
        file_print(flog, "\nSearch for certificates in available stores:\n");
#endif
        rc = VCERT_FindCert(
            hCtx[0],
            &find_p,
            &find_r);

        if (!rc)
        {
            for (idx = 0; idx < (int) find_r.num; idx ++)
            {
#ifdef RUSSIAN
                file_print(flog, "\n����䨪�� �%d:\n", idx + 1);
#else
                file_print(flog, "\nCertificate %d:\n", idx + 1);
#endif
                certificate_print(flog, &find_r.certs[idx]);
            }

            file_print(flog, "\n");
        }
    }
    else if (openpr)
    {
#ifdef RUSSIAN
        file_print(flog, "\n��ॡ�� ����஥���� ��䨫��:\n");
#else
        file_print(flog, "\nConfigured profile enumeration:\n");
#endif

        for (idx = 0; ; idx ++)
        {
            mem_blk_t mprf = { 0 };
            mem_blk_t mpse = { 0 };
            mem_blk_t mloc = { 0 };
            mem_blk_t mldp = { 0 };
            char      * sprf;
            char      * spse;
            char      * sloc;
            char      * sldp;

            rc = VCERT_QueryRegistryProfileEx(hCtx[0], &mprf, &mpse, &mloc, &mldp, (uint32_t) idx);
            if (rc)
                break;

            sprf = char_to_oem((const char *) mprf.buf);
#ifdef _WIN32
            spse = char_to_oem((const char *) mpse.buf);
            sloc = char_to_oem((const char *) mloc.buf);
            if (mldp.buf)
                sldp = char_to_oem((const char *) mldp.buf);
#else  /* _WIN32 */
            spse = (char *) mpse.buf;
            sloc = (char *) mloc.buf;
            sldp = (char *) mldp.buf;
#endif /* _WIN32 */

#ifdef RUSSIAN
            file_print(flog, "\n��䨫� �%d:\n", idx + 1);
            file_print(flog, "��������: %s\n", sprf);
            file_print(flog, "���.....: %s\n", spse);
            file_print(flog, "���.....: %s\n", sloc);
            if (mldp.buf)
                file_print(flog, "���.....: %s\n", sldp);
#else
            file_print(flog, "\nProfile %d:\n", idx + 1);
            file_print(flog, "Name: %s\n", sprf);
            file_print(flog, "PSE.: %s\n", spse);
            file_print(flog, "LCS.: %s\n", sloc);
            if (mldp.buf)
                file_print(flog, "NCS.: %s\n", sldp);
#endif

            if (sprf != (char *) mprf.buf)
                free(sprf);
            if (spse != (char *) mpse.buf)
                free(spse);
            if (sloc != (char *) mloc.buf)
                free(sloc);
            if (mldp.buf)
                if (sldp != (char *) mldp.buf)
                    free(sldp);

            VCERT_FreeMem(hCtx[0], mprf.buf);
            VCERT_FreeMem(hCtx[0], mpse.buf);
            VCERT_FreeMem(hCtx[0], mloc.buf);
            VCERT_FreeMem(hCtx[0], mldp.buf);
        }

        file_print(flog, "\n");
    }
    else if (opcrpr)
    {
        char * sprofil = oem_to_char(profile);
#ifdef RUSSIAN
        file_print(flog, "\n�������� ��� ����䨪��� ��䨫�\n");
#else
        file_print(flog, "\nProfile creation or modification\n");
#endif
        rc = VCERT_CreateRegistryProfileEx(
            hCtx[0],
            (string_t) sprofil,
            uripse,
            uriloc,
            urildp,
            FLAG_CREATE_REGISTRY_PROFILE_OVER);

        if (sprofil != profile)
            free(sprofil);
    }
    else if (opcrst)
    {
#ifdef RUSSIAN
        file_print(flog, "\n�������� �࠭���� ��� � ��� �� �������� ���䨪�⮢ � ���\n");
#else
        file_print(flog, "\nCreate PSE and LCS stores with given certificates and CRLs\n");
#endif
        rc = VCERT_CreateCertificateStore(
            hCtx[0],
            mcer,
            (uint32_t) ncer,
            mcrl,
            (uint32_t) ncrl,
            uripse,
            uriloc,
            0);
    }
    else if (opimob)
    {
#ifdef RUSSIAN
        file_print(flog, "\n������ ���䨪��, ���, ��� ���������� �� �� ��� ��\n");
#else
        file_print(flog, "\nImport certificate, CRL, or CA- or RA-signed update\n");
#endif
        if (import_p.flag & FLAG_IMPORT_CERTWITHPRIVATE)
            rc = VCERT_ImportFile(
                hCtx[0],
                &import_p,
                finp);
        else
        {
            import_p.flag |= FLAG_IMPORT_CERTDERPEMFORMAT;

            rc = VCERT_ImportFile(
                hCtx[0],
                &import_p,
                finp);
            if (rc == VCERT_E_CERT_DAMAGED)
            {
                import_p.flag &= ~FLAG_IMPORT_CERTDERPEMFORMAT;
                import_p.flag |= FLAG_IMPORT_CRLDERPEMFORMAT;

                rc = VCERT_ImportFile(
                    hCtx[0],
                    &import_p,
                    finp);
                if (rc == VCERT_E_CRL_DAMAGED)
                {
                    import_p.flag &= ~FLAG_IMPORT_CRLDERPEMFORMAT;
                    import_p.flag |= FLAG_IMPORT_SIGNEDCARAUPDATE;

                    rc = VCERT_ImportFile(
                        hCtx[0],
                        &import_p,
                        finp);
                }
            }
        }
    }
    else if (opexrq)
    {
#ifdef RUSSIAN
        file_print(flog, "\n��ᯮ�� ����� PKCS#10 ��� ����� �� ���㫨஢���� ���䨪��\n");
#else
        file_print(flog, "\nExport PKCS#10 request or certificate revocation request\n");
#endif
        if (export_p.flag & FLAG_EXPORT_REVOKEREQUEST)
            rc = VCERT_ExportFile(
                hCtx[0],
                &export_p,
                fout);
        else
            if (minimal)
            {
                mem_blk_t mreq = { 0 };
                flag_t    flag = 0;

                if (fdat)
                {
                    rc = file_mmap(fdat, (void **) &mdat.buf, (int *) &mdat.len);
                    if (rc)
                        goto err;

                    flag = FLAG_CTRL_XMLREQ_FOR_ENCRYPTION;

                    if (export_p.flag & FLAG_EXPORT_GOST_R_34_10_12_512)
                        flag |= FLAG_CTRL_XMLREQ_GOST_R_34_10_12_512;
                    else
                        flag |= FLAG_CTRL_XMLREQ_GOST_R_34_10_12_256;

                    if (export_p.flag & FLAG_EXPORT_CARRIER_GENERATION)
                        flag |= FLAG_CTRL_XMLREQ_CARRIER_GENERATION;
                }

                rc = VCERT_ControlEx(
                    hCtx[0],
                    NULL,
                    VCERT_CMD_XMLREQ_WIZARD,
                    &mdat,
                    &mreq,
                    flag);
                if (!rc)
                {
#ifdef _LOCAL_
                    if (fdat && (export_p.flag & FLAG_EXPORT_SHOWREQUESTUI))
                        rc = VCERT_ShowRequestEx(hCtx[0], NULL, &mreq);
#endif /* _LOCAL_ */

                    if (!rc)
                    {
                        FILE * freq = NULL;

                        freq = fopen(fout, "wb");
                        if (freq)
                        {
                            if (fwrite(mreq.buf, 1, mreq.len, freq) != mreq.len)
                                rc = VCERT_E_WRITE_FILE;

                            fclose(freq);
                        }
                        else
                            rc = VCERT_E_OPEN_OUTFILE;
                    }

                    VCERT_FreeMem(hCtx[0], mreq.buf);
                }
            }
            else
            {
                export_p.flag |= FLAG_EXPORT_PKCS10REQUEST;

                if ((export_p.flag & FLAG_EXPORT_GOST_R_34_10_12_512) == 0)
                    export_p.flag |= FLAG_EXPORT_GOST_R_34_10_12_256;

                rc = VCERT_ExportFile(
                    hCtx[0],
                    &export_p,
                    fout);
            }
    }

 err:
    if (query)
        free(query);

    if (find_p.certTemplate.fields & FIELD_SUBJECT)
        free(find_p.certTemplate.subject);

    if (find_p.certTemplate.fields & FIELD_ISSUER)
        free(find_p.certTemplate.issuer);

    if (find_p.certTemplate.fields & FIELD_SERIAL)
        free(find_p.certTemplate.serialNumber);

    if (find_p.certTemplate.fields & FIELD_CERTHASH)
        free(find_p.certTemplate.certHash.buf);

    if (find_p.certTemplate.fields & FIELD_SUBJECTALTNAME)
        free(find_p.certTemplate.subjectAltName.emailAddress);

    if (find_p.certTemplate.fields & FIELD_KEYID)
        free(find_p.certTemplate.keyId);

    if (find_p.certTemplate.fields & FIELD_EXTENSIONS)
        free(find_p.certTemplate.extensions[0].data);

    if (msig.buf && msig.buf != (void *) -1)
#ifdef _WIN32
        UnmapViewOfFile(msig.buf);
#else  /* _WIN32 */
        munmap(msig.buf, (size_t) msig.len);
#endif /* _WIN32 */

    if (mdat.buf && mdat.buf != (void *) -1)
#ifdef _WIN32
        UnmapViewOfFile(mdat.buf);
#else  /* _WIN32 */
        munmap(mdat.buf, (size_t) mdat.len);
#endif /* _WIN32 */

    for (idx = 0; idx < ncer; idx ++)
        if (mcer[idx].buf && mcer[idx].buf != (void *) -1)
#ifdef _WIN32
            UnmapViewOfFile(mcer[idx].buf);
#else  /* _WIN32 */
            munmap(mcer[idx].buf, (size_t) mcer[idx].len);
#endif /* _WIN32 */

    for (idx = 0; idx < ncrl; idx ++)
        if (mcrl[idx].buf && mcrl[idx].buf != (void *) -1)
#ifdef _WIN32
            UnmapViewOfFile(mcrl[idx].buf);
#else  /* _WIN32 */
            munmap(mcrl[idx].buf, (size_t) mcrl[idx].len);
#endif /* _WIN32 */

    return rc;
}
