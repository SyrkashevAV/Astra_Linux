/*
 * Copyright (C) �� ����� 1997-1999
 * Copyright (C) �������� 1999-2018
 * ��� 䠩� ᮤ�ন� ���ଠ��,
 * ������� ᮡ�⢥������� �������� ��������.
 *
 * �� ���� �⮣� 䠩�� �� ����� ���� ᪮��஢���,
 * ��ࠢ����, ��ॢ����� �� ��㣨� �모,
 * ������������ ��� ������஢��� ��� ᯮᮡ��,
 * �⪮�����஢���, ��।��� �� �� � ��� ��
 * ���� ���������� ��⥬� ��� �।���⥫쭮��
 * �����祭�� ᮣ��襭�� � ��������� ��������.
 */

/******************************************************************************/

#include <stdio.h>
#include <stdarg.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <ctype.h>
#include <fcntl.h>
#include <time.h>

#ifdef _WIN32
#include <windows.h>
#include <process.h>
#include <io.h>
#define strcasecmp  stricmp
#else  /* _WIN32 */
#include <sys/mman.h>
#include <sys/time.h>
#include <pthread.h>
#include <signal.h>
#include <unistd.h>
#include <errno.h>
#include <iconv.h>
#endif /* _WIN32 */

#include <vcert1.h>
#include <vcerterr.h>

#include <openssl/vcertv.h>

#include "getopt.h"

/******************************************************************************/

#define MAX_NUM     1024

/******************************************************************************/

extern int                  print_help;

extern const char           * profile;
extern int                  registry;
extern int                  minimal;

extern int                  ophash;
extern int                  opsign;
extern int                  opvrfy;
extern int                  opencr;
extern int                  opdecr;
extern int                  msginf;
extern int                  optssg;
extern int                  optsvr;
extern int                  opocin;
extern int                  optool;

extern int                  opatta;
extern int                  opdeta;
extern int                  openob;
extern int                  opfncr;
extern int                  opsped;
extern int                  openpr;
extern int                  opcrpr;
extern int                  opcrst;
extern int                  opimob;
extern int                  opexrq;

extern int                  ldap;
extern int                  aiacdp;
extern int                  sendcert;
extern string_t             algorithm;
extern int                  format;
extern const char           * logfile;
extern FILE                 * flog;

extern const char           * finp;
extern const char           * fout;
extern const char           * fdat;

extern int                  num_recipients;
extern certificate_t        recipients[MAX_NUM];

extern int                  num_extkeyus;
extern const char           * extkeyus[MAX_NUM];
extern int                  num_policies;
extern const char           * policies[MAX_NUM];

extern const char           * url;

extern certinfo_t           fields;
extern int                  stream;
extern int                  detached;
extern int                  crlupdate;
extern int                  critical;

extern string_t             query;

extern int                  iterat;
extern int                  threads;

extern const char           * uripse;
extern const char           * uriloc;
extern const char           * urildp;

extern flag_t               flag;

extern certid_t             certid;
extern mem_blk_t            passwd;

extern mem_blk_t            hash_r;

extern sign_param_t         sign_p;

extern verify_param_t       verify_p;
extern verify_result_t      verify_r;

extern verify_policy_param_t
                            policy_p;

extern encrypt_param_t      encrypt_p;

extern decrypt_param_t      decrypt_p;
extern decrypt_result_t     decrypt_r;

extern cms_msginf_t         msginf_r;

extern tsp_request_param_t  tssign_p;

extern tsp_verify_param_t   tsverif_p;
extern tsp_verify_result_t  tsverif_r;

extern ocsp_request_param_t ocspsig_p;

extern ocsp_verify_param_t  ocspver_p;
extern ocsp_verify_result_t ocspver_r;

extern extension_t          extn_p;
extern find_param_t         find_p;
extern find_result_t        find_r;

extern import_param_t       import_p;
extern export_param_t       export_p;

extern context_t            hCtx[2];

/******************************************************************************/

char *
oem_to_char(
    const char * string);

/******************************************************************************/

char *
char_to_oem(
    const char * string);

/******************************************************************************/

int
file_print(
    FILE * stream,
    const char * format,
    ...);

/******************************************************************************/

char *
hex2string(
    unsigned char * buffer,
    int len);

/******************************************************************************/

unsigned char *
string2hex(
    char * str,
    int * len);

/******************************************************************************/

#ifdef _WIN32

int
load_recipients(
    const char * fileName,
    certificate_t * arrRecips,
    int * numRecips);

#endif /* _WIN32 */

/******************************************************************************/

void
certificate_print(
    FILE * file,
    certificate_t * cert);

/******************************************************************************/

void
crl_print(
    FILE * file,
    crl_t * crl);

/******************************************************************************/

void
msginf_print(
    FILE * file,
    cms_msginf_t * info);

/******************************************************************************/

int
tools_main(
    int argc,
    char ** argv);

/******************************************************************************/

void
status_print(
    FILE * file,
    error_status_t rc,
    int cnt);

/******************************************************************************/

int
file_mmap(
    const char * fname,
    void ** ptr,
    int * len);
